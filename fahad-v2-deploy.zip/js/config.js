/* config.js — public client configuration.
 * The publishable key is designed to be public: all access is enforced by RLS.
 * NEVER put a service_role key, SMS provider key, or OAuth client secret in this folder. */
window.FM_CONFIG = Object.freeze({
  SUPABASE_URL: 'https://jujkckphabzsfjcodefy.supabase.co',
  SUPABASE_KEY: 'sb_publishable_yo1_aLrYJhMXPKZdvcNVYw_8SuyBQp3',
  DEFAULT_DIAL: '+966',
  OTP_RESEND_SECONDS: 60
});
