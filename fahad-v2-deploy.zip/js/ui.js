/* ui.js — motion & small UX helpers (no data, no auth). */
(() => {
  'use strict';
  const view = document.getElementById('view');
  const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* reveal-on-scroll */
  let io = null;
  if ('IntersectionObserver' in window && !reduce) {
    io = new IntersectionObserver(entries => {
      entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.06 });
  }
  const SEL = '.section-head, .content-card, .service-card, .metric, .gallery-item, .about-art, .about-content, .contact-banner, .fx-q, .fx-lib .panel, .fx-tl li, .stat-card';
  function scan() {
    if (!io || !view) return;
    view.querySelectorAll(SEL).forEach((el, i) => {
      if (el.dataset.rv) return;
      el.dataset.rv = '1';
      el.classList.add('reveal');
      el.style.transitionDelay = (Math.min(i % 6, 5) * 70) + 'ms';
      io.observe(el);
    });
  }
  if (view) {
    new MutationObserver(() => requestAnimationFrame(scan)).observe(view, { childList: true });
    requestAnimationFrame(scan);
  }

  /* card spotlight follows the pointer */
  document.addEventListener('pointermove', e => {
    const card = e.target.closest && e.target.closest('.content-card');
    if (!card) return;
    const r = card.getBoundingClientRect();
    card.style.setProperty('--mx', (e.clientX - r.left) + 'px');
    card.style.setProperty('--my', (e.clientY - r.top) + 'px');
  }, { passive: true });

  /* inputs that should select their text on focus (CSP-safe replacement for inline onclick) */
  document.addEventListener('focusin', e => {
    if (e.target.matches && e.target.matches('[data-select-all]')) e.target.select();
  });
  document.addEventListener('click', e => {
    if (e.target.matches && e.target.matches('[data-select-all]')) e.target.select();
  });
})();
