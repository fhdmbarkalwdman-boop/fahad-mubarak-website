/* boot.js — runs before first paint: theme + safety valve for the loading gate. */
(function () {
  'use strict';
  try {
    if (localStorage.getItem('fahad_theme') === 'dark') document.documentElement.dataset.theme = 'dark';
  } catch (e) { /* storage may be blocked */ }
  // If anything fails to load, never leave the visitor on the splash screen.
  setTimeout(function () {
    if (document.documentElement.getAttribute('data-gate') === 'pending') {
      document.documentElement.setAttribute('data-gate', 'open');
    }
  }, 8000);
})();
