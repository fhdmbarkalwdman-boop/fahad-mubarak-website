/* ============================================================
   maintenance.js — maintenance mode (gate + admin tab)
   - state lives in Supabase: site_settings key = 'maintenance'
   - owner can toggle/edit from the admin dashboard
   - visitors see the maintenance page; owner (and the login screens) stay reachable
   - flips live for open tabs through Realtime (+ a slow poll as fallback)
   ============================================================ */
(() => {
  'use strict';
  const FM = window.FM, CFG = window.FM_CONFIG, esc = FM.esc, ic = FM.icon;
  const root = document.getElementById('maint-root');
  const DEFAULT = { enabled: false, title: 'الموقع قيد الصيانة', message: 'نعمل حاليًا على تطوير الموقع لنقدّم لكم تجربة أفضل. سنعود قريبًا بإذن الله.', eta: '' };
  const REACHABLE = /^(login|forgot|reset|authcb|setup)$/; // the owner must be able to sign in
  const SQL_FIX = `-- شغّله مرة واحدة من Supabase → SQL Editor
alter policy site_settings_public_read on public.site_settings
  using (key = any (array['public_profile','homepage','navigation','theme','maintenance']));

insert into public.site_settings (key, value)
values ('maintenance', '{"enabled": false}'::jsonb)
on conflict (key) do nothing;`;
  let state = { ...DEFAULT }, started = false, channel = null, poll = 0, diag = null;

  const user = () => window.FahadSupabase?.user || null;
  const isOwner = () => user()?.role === 'owner';
  const client = () => window.FahadSupabase?.client || null;
  const route = () => { try { return decodeURIComponent((location.hash || '#home').slice(1)); } catch { return ''; } };
  const clean = v => ({
    enabled: v?.enabled === true,
    title: String(v?.title || DEFAULT.title).slice(0, 120),
    message: String(v?.message || DEFAULT.message).slice(0, 1200),
    eta: String(v?.eta || '').slice(0, 64)
  });
  const fmtEta = eta => {
    if (!eta) return '';
    const d = new Date(eta);
    if (isNaN(d)) return eta;
    try { return new Intl.DateTimeFormat('ar-SA-u-ca-gregory-nu-latn', { dateStyle: 'full', timeStyle: 'short' }).format(d); } catch { return d.toLocaleString(); }
  };

  /* ---------- the public maintenance page ---------- */
  const gear = (cls) => `<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><circle cx="24" cy="24" r="7"/><path d="M24 4v6M24 38v6M4 24h6M38 24h6M9.9 9.9l4.2 4.2M33.9 33.9l4.2 4.2M9.9 38.1l4.2-4.2M33.9 14.1l4.2-4.2"/><circle cx="24" cy="24" r="15"/></svg>`;
  function pageHtml(s, preview) {
    const eta = fmtEta(s.eta);
    return `<div class="maint" role="alert" aria-live="polite"><div class="hero-aurora" aria-hidden="true"><i></i><i></i><i></i></div>
      <div class="maint-card">
        <div class="maint-brand"><span class="brand-mark">F<span>.</span></span><span><strong>${esc(FM.store.settings.siteName)}</strong><small>FAHAD MUBARAK</small></span></div>
        <div class="maint-gears">${gear('g1')}${gear('g2')}</div>
        <h1>${esc(s.title)}</h1>
        <p class="msg">${esc(s.message)}</p>
        ${eta ? `<div class="maint-eta">${ic('clock')} العودة المتوقعة: ${esc(eta)}</div>` : ''}
        <div class="maint-bar" aria-hidden="true"><i></i></div>
        ${preview ? '' : `<a class="maint-admin" href="#login">${ic('lock')} دخول الإدارة</a>`}
      </div></div>`;
  }

  /* ---------- gate ---------- */
  function setInert(on) {
    ['site-header', 'view', 'site-footer'].forEach(id => { const el = document.getElementById(id); if (!el) return; if (on) el.setAttribute('inert', ''); else el.removeAttribute('inert'); });
  }
  function apply() {
    const on = state.enabled, owner = isOwner();
    document.documentElement.dataset.maint = on ? (owner ? 'owner' : 'gate') : 'off';
    const blocked = on && !owner && !REACHABLE.test(route());
    if (blocked) { root.innerHTML = pageHtml(state, false); setInert(true); }
    else { if (root.firstChild) root.innerHTML = ''; setInert(false); }
    let banner = document.querySelector('.maint-banner');
    if (on && owner) {
      if (!banner) { document.body.insertAdjacentHTML('beforeend', `<div class="maint-banner" role="status">وضع الصيانة مفعّل — الزوار لا يرون الموقع <a href="#admin">إدارة</a></div>`); }
    } else if (banner) banner.remove();
  }
  document.head.insertAdjacentHTML('beforeend', '<style>html[data-maint="gate"] .site-header,html[data-maint="gate"] .site-footer,html[data-maint="gate"] .sidebar,html[data-maint="gate"] .sidebar-backdrop,html[data-maint="gate"] .back-top{display:none!important}</style>');

  async function fetchState() {
    const c = client(); if (!c) return false;
    const { data, error } = await c.from('site_settings').select('value').eq('key', 'maintenance').maybeSingle();
    if (error) return false; // fail OPEN: a read problem must never lock the whole site
    state = clean(data?.value || DEFAULT);
    return true;
  }
  async function refresh() { await fetchState(); apply(); if (document.querySelector('[data-maint-tab]')) FM.refresh(); }

  function subscribe() {
    const c = client(); if (!c || channel) return;
    channel = c.channel('fm-maintenance').on('postgres_changes', { event: '*', schema: 'public', table: 'site_settings', filter: 'key=eq.maintenance' }, () => refresh()).subscribe();
    clearInterval(poll); poll = setInterval(() => { if (!document.hidden) refresh(); }, 60000);
  }

  async function start() {
    if (started) return; started = true;
    try { await fetchState(); subscribe(); } catch { /* fail open */ }
    apply();
    document.documentElement.dataset.gate = 'open';
  }
  document.addEventListener('fm:supabase-auth', e => {
    if (!e.detail?.ready) return;
    if (!started) start(); else apply();
  });
  if (window.FahadSupabase?.ready) start();
  else { const w = setInterval(() => { if (window.FahadSupabase?.ready) { clearInterval(w); start(); } }, 150); setTimeout(() => clearInterval(w), 7000); }
  window.addEventListener('hashchange', apply);
  window.addEventListener('focus', () => { if (started) refresh(); });
  setTimeout(() => { if (!started) { started = true; apply(); document.documentElement.dataset.gate = 'open'; } }, 6500);

  /* ---------- admin tab ---------- */
  const toLocalInput = iso => { const d = new Date(iso); if (!iso || isNaN(d)) return ''; const p = n => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`; };
  function diagHtml() {
    if (!diag) return '<div class="diag wait">لم يُجرَ الفحص بعد.</div>';
    const row = (ok, t) => `<div class="diag ${ok === null ? 'wait' : ok ? 'ok' : 'bad'}">${ic(ok ? 'check' : 'info')} <span>${t}</span></div>`;
    let h = row(diag.read, diag.read ? 'الزائر يستطيع قراءة حالة الصيانة (الربط سليم).' : 'الزائر لا يستطيع قراءة حالة الصيانة — صفحة الصيانة لن تظهر له.');
    h += row(diag.rls, diag.rls ? 'الحجب على مستوى قاعدة البيانات مفعّل (المحتوى لا يُقرأ أثناء الصيانة).' : 'الحجب على مستوى قاعدة البيانات غير مطبّق (اختياري): الصفحة تعمل لكن المحتوى يبقى قابلًا للقراءة عبر API.');
    if (!diag.read) h += `<p class="muted" style="margin-top:12px">شغّل هذا الأمر مرة واحدة في SQL Editor ثم اضغط «فحص الربط»:</p><pre class="code-block">${esc(SQL_FIX)}</pre><p class="muted">أو شغّل الملف الكامل <code>supabase/migrations/20261108_v2_auth_maintenance.sql</code> المرفق بالمشروع.</p>`;
    return h;
  }
  const FIELD = (l, h) => `<div class="field wide"><label>${l}</label>${h}</div>`;
  function render() {
    const on = state.enabled;
    return `<div data-maint-tab><div class="page-head"><div><span class="eyebrow">إدارة الموقع</span><h1>وضع الصيانة</h1><p class="muted">أغلق الموقع مؤقتًا أمام الزوار مع بقاء لوحة الإدارة متاحة لك.</p></div></div>
    <div class="maint-panel">
      <section class="maint-status ${on ? 'on' : ''}"><div><h2>حالة الموقع: <span class="badge ${on ? 'draft' : 'published'}">${on ? 'في وضع الصيانة' : 'مفتوح للجميع'}</span></h2><p class="muted" style="margin:0">${on ? 'الزوار والأعضاء يرون صفحة الصيانة الآن. أنت فقط تتصفح الموقع.' : 'الموقع يعمل بشكل طبيعي لجميع الزوار.'}</p></div>
        <label class="switch" title="تفعيل / إيقاف وضع الصيانة"><input type="checkbox" data-maint-toggle ${on ? 'checked' : ''} aria-label="تفعيل وضع الصيانة"><i></i></label></section>
      <form class="panel" data-admin-form="maintenance" novalidate><h2>رسالة الصيانة</h2><p class="muted">تظهر للزوار في صفحة الصيانة.</p>
        <div class="form-grid">${FIELD('العنوان', `<input name="title" maxlength="120" required value="${esc(state.title)}">`)}${FIELD('الرسالة', `<textarea name="message" maxlength="1200" required>${esc(state.message)}</textarea>`)}
        <div class="field"><label>موعد العودة المتوقع (اختياري)</label><input name="eta" type="datetime-local" value="${esc(toLocalInput(state.eta))}"></div></div>
        <div class="form-actions"><button class="btn btn-primary" type="submit">${ic('check')} حفظ الرسالة</button><button class="btn btn-outline" type="button" data-admin-action="maint-preview">${ic('eye')} معاينة الصفحة</button><button class="btn btn-ghost" type="button" data-admin-action="maint-reset">استعادة النص الافتراضي</button></div></form>
      <section class="panel"><div class="row" style="justify-content:space-between;flex-wrap:wrap"><div><h2 style="margin:0">فحص الربط</h2><p class="muted" style="margin:4px 0 0">يقرأ الإعداد كزائر مجهول للتأكد أن الصيانة ستظهر فعلًا.</p></div><button class="btn btn-outline btn-sm" type="button" data-admin-action="maint-check">${ic('refresh')} فحص الربط</button></div><div style="display:grid;gap:10px;margin-top:16px" data-maint-diag>${diagHtml()}</div></section>
    </div></div>`;
  }

  async function runDiag() {
    const out = document.querySelector('[data-maint-diag]'); if (out) out.innerHTML = '<div class="diag wait"><span class="spin"></span> جارٍ الفحص…</div>';
    const res = { read: false, rls: false };
    try {
      const anon = window.supabase.createClient(CFG.SUPABASE_URL, CFG.SUPABASE_KEY, { auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false } });
      const r = await anon.from('site_settings').select('value').eq('key', 'maintenance').maybeSingle();
      res.read = !r.error && !!r.data && (r.data.value?.enabled === state.enabled);
      const f = await anon.rpc('is_maintenance_on');
      res.rls = !f.error && f.data === state.enabled;
    } catch { /* leave false */ }
    diag = res;
    const el = document.querySelector('[data-maint-diag]'); if (el) el.innerHTML = diagHtml();
    return res;
  }

  async function save(patch, okMsg) {
    if (!isOwner()) return FM.toast('المالك فقط يستطيع تغيير وضع الصيانة.', true);
    const c = client(), next = clean({ ...state, ...patch });
    const { error } = await c.from('site_settings').upsert({ key: 'maintenance', value: next, updated_by: user().id, updated_at: new Date().toISOString() }, { onConflict: 'key' });
    if (error) { FM.toast('تعذر الحفظ: ' + error.message, true); return false; }
    state = next; apply();
    window.FahadCloud?.logAction?.(okMsg);
    FM.toast(okMsg); FM.refresh();
    setTimeout(runDiag, 300);
    return true;
  }

  document.addEventListener('change', async e => {
    const t = e.target.closest('[data-maint-toggle]'); if (!t) return;
    const want = t.checked;
    const msg = want ? 'تفعيل وضع الصيانة؟ سيرى جميع الزوار والأعضاء صفحة الصيانة فورًا (أنت ستتصفح الموقع بشكل طبيعي).' : 'إيقاف وضع الصيانة وفتح الموقع للجميع؟';
    if (!window.confirm(msg)) { t.checked = !want; return; }
    t.disabled = true;
    const ok = await save({ enabled: want }, want ? 'تم تفعيل وضع الصيانة' : 'تم إيقاف وضع الصيانة');
    if (!ok) { t.checked = !want; t.disabled = false; }
  });

  window.FMMaint = {
    render, isOn: () => state.enabled === true && isOwner(),
    async submit(form) {
      const d = new FormData(form), title = String(d.get('title') || '').trim(), message = String(d.get('message') || '').trim();
      if (title.length < 3 || message.length < 5) return FM.toast('أدخل عنوانًا ورسالة واضحين.', true);
      const etaRaw = String(d.get('eta') || ''); const eta = etaRaw ? new Date(etaRaw).toISOString() : '';
      await save({ title, message, eta }, 'تم حفظ رسالة الصيانة');
    },
    async click(action) {
      if (action === 'maint-preview') return FM.showModal('معاينة صفحة الصيانة', `<div style="position:relative;height:min(70vh,560px);overflow:hidden;border-radius:18px;background:#030918;transform:translateZ(0)"><div style="position:absolute;inset:0;overflow:auto;transform:scale(.62);transform-origin:top center;width:162%;margin-inline-start:-31%">${pageHtml(clean({ ...state, ...Object.fromEntries(new FormData(document.querySelector('form[data-admin-form="maintenance"]'))) , eta: state.eta }), true).replace('class="maint"', 'class="maint" style="position:relative;min-height:760px"')}</div></div>`);
      if (action === 'maint-check') return runDiag();
      if (action === 'maint-reset') { if (window.confirm('استعادة العنوان والرسالة الافتراضيين؟')) await save({ title: DEFAULT.title, message: DEFAULT.message, eta: '' }, 'تمت استعادة نص الصيانة الافتراضي'); }
    },
    get state() { return { ...state }; },
    refresh
  };
})();
