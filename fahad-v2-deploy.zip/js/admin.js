/*
 * FMAdmin — local-only admin, CMS and authentication UI for a single-file RTL site.
 * It intentionally relies only on the window.FM contract supplied by the parent page.

 */
(function (window, document) {
  'use strict';

  var FM = window.FM;
  var state = { tab: 'dashboard', itemType: 'all', itemStatus: 'all', query: '' };
  var TYPES = ['news', 'article', 'project', 'gallery', 'service', 'achievement', 'timeline', 'note', 'library', 'faq'];
  var STATUS = ['published', 'pending', 'draft', 'archived', 'trash'];
  var CONSULTATION_CATEGORIES = ['general', 'content', 'technical', 'account', 'other'];
  var consultationCategoryNames = { general: 'استشارة عامة', content: 'محتوى الموقع', technical: 'مشكلة تقنية', account: 'الحساب', other: 'أخرى' };
  var consultationStatusNames = { pending: 'قيد المراجعة', replied: 'تم الرد', closed: 'مغلق' };
  var typeNames = { news: 'أخبار', article: 'مقالات', project: 'مشاريع', gallery: 'معرض', service: 'خدمات', achievement: 'إنجازات', timeline: 'محطات الرحلة', note: 'مذكرات', library: 'مكتبة', faq: 'أسئلة شائعة' };
  var statusNames = { published: 'منشور', pending: 'بانتظار المراجعة', draft: 'مسودة', archived: 'مؤرشف', trash: 'سلة المحذوفات' };


  function esc(value) {
    var str = value === null || value === undefined ? '' : String(value);
    return FM && typeof FM.esc === 'function' ? FM.esc(str) : str.replace(/[&<>'"]/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[c]; });
  }
  function attr(value) { return esc(value); }
  function store() {
    if (!FM) return { settings: {}, items: [], users: [], comments: [], contacts: [], consultations: [], favorites: [], activity: [] };
    FM.store = FM.store || {};
    var s = FM.store;
    s.settings = s.settings || {};
    ['items', 'users', 'comments', 'contacts', 'consultations', 'favorites', 'activity'].forEach(function (key) { if (!Array.isArray(s[key])) s[key] = []; });
    return s;
  }
  function defaults() {
    var settings = store().settings;
    var visible = settings.visible || (settings.visible = {});
    ['news', 'article', 'project', 'gallery', 'service', 'about', 'contact'].forEach(function (key) { if (typeof visible[key] !== 'boolean') visible[key] = true; });
    if (!settings.primary) settings.primary = '#2458ef';
    return settings;
  }
  function uid() { return FM && typeof FM.uid === 'function' ? FM.uid() : 'fm-' + Date.now() + '-' + Math.random().toString(36).slice(2, 9); }
  function save() { if (FM && typeof FM.save === 'function') FM.save(); }
  function toast(message, isError) { if (FM && typeof FM.toast === 'function') FM.toast(message, !!isError); else window.alert(message); }
  function navigate(route) { if (FM && typeof FM.navigate === 'function') FM.navigate(route); }
  function refresh() { if (FM && typeof FM.refresh === 'function') FM.refresh(); }
  function formattedDate(value) {
    if (FM && typeof FM.date === 'function') return FM.date(value);
    try { return new Intl.DateTimeFormat('ar-SA', { dateStyle: 'medium' }).format(new Date(value)); } catch (e) { return String(value || '—'); }
  }
  function now() { return new Date().toISOString(); }
  function activeUser() { return FM && typeof FM.user === 'function' ? FM.user() : null; }
  function log(message) {
    var s = store(); var before = s.activity.length;
    if (FM && typeof FM.log === 'function') FM.log(message);
    if (s.activity.length === before) s.activity.unshift({ id: uid(), message: message, userId: activeUser() ? activeUser().id : null, createdAt: now() });
  }
  function hasContentPermission(user) {
    var p = user && Array.isArray(user.permissions) ? user.permissions : [];
    return p.indexOf('content') > -1 || p.indexOf('manage_content') > -1 || p.indexOf('admin') > -1;
  }
  function isOwner(user) { return !!(user && user.active !== false && user.role === 'owner'); }
  function isAdmin(user) {
    if (!user || user.active === false) return false;
    if (isOwner(user)) return true;
    return user.role === 'editor' && hasContentPermission(user);
  }
  function can(user, feature) {
    if (!isAdmin(user)) return false;
    if (isOwner(user)) return true;
    return feature === 'dashboard' || (feature === 'content' && hasContentPermission(user));
  }
  function normalize(value) { return String(value || '').trim().toLowerCase(); }
  function safeImage(url) { return /^data:image\/(?:png|jpe?g|webp|gif);base64,/i.test(String(url || '')) ? String(url) : ''; }
  function pageHead(title, text, action) { return '<div class="page-head"><div><span class="eyebrow">إدارة الموقع</span><h1>' + esc(title) + '</h1>' + (text ? '<p class="muted">' + esc(text) + '</p>' : '') + '</div>' + (action || '') + '</div>'; }

  function consultationCategory(value) { return CONSULTATION_CATEGORIES.indexOf(value) > -1 ? value : 'general'; }
  function consultationStatus(record) {
    var value = String(record && record.status || '');
    if (Object.prototype.hasOwnProperty.call(consultationStatusNames, value)) return value;
    return consultationReply(record) ? 'replied' : 'pending';
  }
  function consultationReply(record) { return String(record && (record.reply || record.response) || '').trim(); }
  function consultationSender(record) {
    var linked = record && record.userId ? store().users.find(function (u) { return u.id === record.userId; }) : null;
    return (linked && (linked.name || linked.username)) || (record && (record.senderName || record.name || record.username)) || 'مستخدم';
  }
  function consultationCategoryOptions(selected) { return CONSULTATION_CATEGORIES.map(function (key) { return '<option value="' + attr(key) + '"' + (consultationCategory(selected) === key ? ' selected' : '') + '>' + esc(consultationCategoryNames[key]) + '</option>'; }).join(''); }
  function renderProfileConsultations(user) {
    var records = store().consultations.filter(function (record) { return record && record.userId === user.id; }).sort(function (a, b) { return String(b.createdAt || b.date || '').localeCompare(String(a.createdAt || a.date || '')); });
    var list = records.length ? '<ul class="activity-list">' + records.map(function (record) {
      var status = consultationStatus(record), reply = consultationReply(record), text = String(record.text || record.body || '').trim();
      return '<li><div class="row" style="align-items:flex-start"><span><strong>' + esc(record.title || 'طلب استشارة') + '</strong><span class="table-sub">' + esc(consultationCategoryNames[consultationCategory(record.category)]) + ' · ' + esc(formattedDate(record.createdAt || record.date)) + '</span></span><span class="badge ' + attr(status) + '">' + esc(consultationStatusNames[status]) + '</span></div><p class="muted" style="white-space:pre-wrap;margin-top:8px">طلبك: ' + esc(text || '—') + '</p>' + (reply ? '<div class="notice" style="margin-top:8px;white-space:pre-wrap"><strong>الرد:</strong><br>' + esc(reply) + '</div>' : '<p class="muted" style="margin-top:8px">لم يصل رد بعد.</p>') + '</li>';
    }).join('') + '</ul>' : '<div class="empty">لا توجد طلبات استشارة في حسابك بعد.</div>';
    return '<section class="panel"><h2>طلب استشارة</h2><form data-admin-form="consultation" novalidate style="margin-top:15px"><div class="form-grid"><div class="field wide"><label>عنوان الطلب *</label><input name="title" maxlength="160" required></div><div class="field"><label>فئة الاستشارة *</label><select name="category" required>' + consultationCategoryOptions('general') + '</select></div><div class="field wide"><label>نص الاستشارة *</label><textarea name="text" maxlength="4000" required placeholder="اكتب تفاصيل طلبك هنا…"></textarea></div></div><div class="form-actions"><button class="btn btn-primary" type="submit">إرسال الطلب</button></div></form></section><section class="panel"><h2>طلباتي وردودي</h2><p class="muted">تظهر هنا طلباتك وأي رد من المالك.</p>' + list + '</section>';
  }
  function guestPanel(title, text) { return '<main class="fm-admin-app" data-fm-admin-root><section class="auth-shell"><div class="panel"><h1>' + esc(title) + '</h1><p class="muted">' + esc(text) + '</p><div class="form-actions"><button class="btn btn-primary" type="button" data-admin-action="navigate" data-route="login">تسجيل الدخول</button></div></div></section></main>'; }

  function typeOptions(selected, includeAll) { return (includeAll ? '<option value="all">كل الأنواع</option>' : '') + TYPES.map(function (t) { return '<option value="' + t + '"' + (t === selected ? ' selected' : '') + '>' + typeNames[t] + '</option>'; }).join(''); }
  function statusOptions(selected, includeAll) { return (includeAll ? '<option value="all">كل الحالات</option>' : '') + STATUS.map(function (s) { return '<option value="' + s + '"' + (s === selected ? ' selected' : '') + '>' + statusNames[s] + '</option>'; }).join(''); }
  function renderContent() {
    var items = store().items.slice().sort(function (a, b) { return String(b.updatedAt || b.createdAt || '').localeCompare(String(a.updatedAt || a.createdAt || '')); });
    var rows = items.map(contentRow).join('');
    return pageHead('إدارة المحتوى', 'أضف وعدّل وأرشف واستعد المحتوى المنشور.', '<button class="btn btn-primary" type="button" data-admin-action="new-item">+ إضافة محتوى</button>') +
      '<section class="panel"><div class="toolbar"><div class="filters"><input data-item-filter="query" value="' + attr(state.query) + '" placeholder="بحث في العنوان أو الملخص…" aria-label="بحث"><select data-item-filter="type" aria-label="نوع المحتوى">' + typeOptions(state.itemType, true) + '</select><select data-item-filter="status" aria-label="الحالة">' + statusOptions(state.itemStatus, true) + '</select></div></div><div class="table-wrap"><table><thead><tr><th>المحتوى</th><th>النوع</th><th>الحالة</th><th>آخر تعديل</th><th>إجراءات</th></tr></thead><tbody data-content-rows>' + (rows || '<tr><td colspan="5"><div class="empty">لا يوجد محتوى بعد. ابدأ بإضافة أول عنصر.</div></td></tr>') + '</tbody></table></div></section>';
  }
  function contentRow(item) {
    var image = safeImage(item.image); var title = esc(item.title || 'بلا عنوان'); var summary = esc(item.summary || '');
    var thumb = image ? '<img class="item-thumb" alt="" src="' + attr(image) + '">' : '<span class="placeholder">بدون صورة</span>';
    var actions = '<button class="icon-btn" type="button" title="تعديل" aria-label="تعديل" data-admin-action="edit-item" data-id="' + attr(item.id) + '">تعديل</button>';
    if (item.status === 'pending') actions += '<button class="icon-btn" type="button" data-admin-action="approve-item" data-id="' + attr(item.id) + '">نشر</button>'; if (item.status === 'trash') actions += '<button class="icon-btn" type="button" data-admin-action="restore-item" data-id="' + attr(item.id) + '">استعادة</button>';
    else { actions += '<button class="icon-btn" type="button" data-admin-action="archive-item" data-id="' + attr(item.id) + '">أرشفة</button><button class="icon-btn danger" type="button" data-admin-action="delete-item" data-id="' + attr(item.id) + '">حذف</button>'; }
    return '<tr data-item-row data-type="' + attr(item.type) + '" data-status="' + attr(item.status) + '" data-search="' + attr((item.title || '') + ' ' + (item.summary || '') + ' ' + (item.category || '')) + '"><td><div class="row" style="justify-content:flex-start"><span>' + thumb + '</span><span><span class="table-title">' + title + (item.by === 'member' ? ' <span class="badge">من عضو: ' + esc(item.author || '') + '</span>' : '') + '</span><span class="table-sub">' + summary + '</span></span></div></td><td>' + esc(typeNames[item.type] || item.type) + '</td><td><span class="badge ' + attr(item.status || 'draft') + '">' + esc(statusNames[item.status] || item.status) + '</span></td><td>' + esc(formattedDate(item.updatedAt || item.createdAt)) + '</td><td><div class="actions">' + actions + '</div></td></tr>';
  }
  function renderSettings() {
    var x = defaults(), v = x.visible || {};
    var sections = [['news','الأخبار'],['article','المقالات'],['project','المشاريع'],['gallery','المعرض'],['service','الخدمات'],['about','من أنا'],['contact','تواصل']];
    var order = Array.isArray(x.sectionOrder) ? x.sectionOrder.slice() : sections.map(function (s) { return s[0]; });
    sections.forEach(function (s) { if (order.indexOf(s[0]) < 0) order.push(s[0]); });
    function visible(name, label) { return '<label class="check"><input type="checkbox" name="visible_' + name + '"' + (v[name] ? ' checked' : '') + '> ' + label + '</label>'; }
    function orderInput(s) { return '<div class="field"><label>' + s[1] + '</label><input type="number" min="1" max="7" name="order_' + s[0] + '" value="' + (order.indexOf(s[0]) + 1) + '" required></div>'; }
    return pageHead('إعدادات الموقع', 'عدّل الهوية ومعلومات التواصل والأقسام العامة.') +
      '<form data-admin-form="settings"><section class="panel"><h2>الهوية والمقدمة</h2><div class="form-grid"><div class="field"><label>اسم الموقع</label><input name="siteName" maxlength="100" required value="' + attr(x.siteName) + '"></div><div class="field"><label>اللون الأساسي</label><input name="primary" type="color" value="' + attr(/^#[0-9a-f]{6}$/i.test(x.primary || '') ? x.primary : '#2458ef') + '"></div><div class="field wide"><label>عنوان الواجهة</label><input name="heroTitle" maxlength="150" value="' + attr(x.heroTitle) + '"></div><div class="field wide"><label>نص الواجهة</label><textarea name="heroText" maxlength="800">' + esc(x.heroText) + '</textarea></div><div class="field wide"><label>نبذة عنك</label><textarea name="about" maxlength="2000">' + esc(x.about) + '</textarea></div></div></section><section class="panel"><h2>التواصل والحسابات</h2><div class="form-grid"><div class="field"><label>البريد الإلكتروني</label><input name="email" type="email" dir="ltr" value="' + attr(x.email) + '"></div><div class="field"><label>رقم الجوال</label><input name="phone" inputmode="tel" value="' + attr(x.phone) + '"></div><div class="field"><label>رابط/معرف X</label><input name="x" dir="ltr" value="' + attr(x.x) + '"></div><div class="field"><label>رابط/معرف سناب شات</label><input name="snapchat" dir="ltr" value="' + attr(x.snapchat) + '"></div></div></section><section class="panel"><h2>الأقسام الظاهرة</h2><div class="visibility-grid">' + sections.map(function (s) { return visible(s[0], s[1]); }).join('') + '</div><h2 style="margin-top:22px">ترتيب أقسام الرئيسية</h2><p class="muted">أدخل ترتيبًا مختلفًا من 1 إلى 7 لكل قسم. الأقسام المخفية لا تظهر حتى تفعيلها.</p><div class="form-grid">' + sections.map(orderInput).join('') + '</div></section><section class="panel"><h2>الصفحات القانونية</h2><p class="muted">اترك الحقل فارغًا لاستعمال النص التمهيدي الافتراضي. راجع النصوص قانونيًا قبل النشر.</p><div class="form-grid"><div class="field wide"><label>الشروط والأحكام</label><textarea name="termsText" maxlength="10000">' + esc(x.termsText || '') + '</textarea></div><div class="field wide"><label>سياسة الخصوصية</label><textarea name="privacyText" maxlength="10000">' + esc(x.privacyText || '') + '</textarea></div></div><div class="form-actions"><button class="btn btn-primary" type="submit">حفظ الإعدادات</button></div></section></form>';
  }
  function consultationStatusOptions(selected) {
    var current = consultationStatus({ status: selected });
    return Object.keys(consultationStatusNames).map(function (key) { return '<option value="' + attr(key) + '"' + (key === current ? ' selected' : '') + '>' + esc(consultationStatusNames[key]) + '</option>'; }).join('');
  }
  function findConsultation(id, index) {
    var records = store().consultations;
    var record = id ? records.find(function (item) { return item && item.id === id; }) : null;
    if (!record && index !== '' && index !== undefined && Number.isInteger(Number(index)) && Number(index) >= 0) record = records[Number(index)];
    return record || null;
  }
  function renderConsultations() {
    var records = store().consultations.map(function (record, index) { return { record: record, index: index }; }).filter(function (entry) { return !!entry.record; }).sort(function (a, b) { return String(b.record.createdAt || b.record.date || '').localeCompare(String(a.record.createdAt || a.record.date || '')); });
    var body = records.length ? records.map(function (entry) {
      var record = entry.record, status = consultationStatus(record), title = record.title || 'طلب استشارة', text = String(record.text || record.body || '').trim();
      return '<tr><td><span class="table-title">' + esc(consultationSender(record)) + '</span><span class="table-sub">' + esc(record.senderEmail || '') + '</span></td><td><span class="table-title">' + esc(title) + '</span><span class="table-sub">' + esc(consultationCategoryNames[consultationCategory(record.category)]) + ' · ' + esc(text || '—') + '</span></td><td><span class="badge ' + attr(status) + '">' + esc(consultationStatusNames[status]) + '</span></td><td>' + esc(formattedDate(record.createdAt || record.date)) + '</td><td><button class="icon-btn" type="button" data-admin-action="view-consultation" data-id="' + attr(record.id || '') + '" data-index="' + attr(entry.index) + '">عرض والرد</button></td></tr>';
    }).join('') : '<tr><td colspan="5"><div class="empty">لا توجد استشارات حتى الآن.</div></td></tr>';
    return pageHead('الاستشارات', 'طلبات الاستشارة الواردة من الأعضاء والرد عليها.') + '<section class="panel"><div class="table-wrap" style="margin-top:14px"><table><thead><tr><th>المرسل</th><th>الطلب</th><th>الحالة</th><th>التاريخ</th><th>إجراء</th></tr></thead><tbody>' + body + '</tbody></table></div></section>';
  }
  function commentText(comment) { return String(comment && (comment.text || comment.body || comment.message || comment.content) || '').trim(); }
  function commentSender(comment) {
    var linked = comment && comment.userId ? store().users.find(function (user) { return user.id === comment.userId; }) : null;
    return (linked && (linked.name || linked.username)) || (comment && (comment.name || comment.senderName || comment.author || comment.username)) || 'مستخدم';
  }
  function renderComments() {
    var comments = store().comments.map(function (comment, index) { return { comment: comment, index: index }; }).filter(function (entry) { return !!entry.comment; }).sort(function (a, b) { return String(b.comment.createdAt || b.comment.date || '').localeCompare(String(a.comment.createdAt || a.comment.date || '')); });
    var body = comments.length ? comments.map(function (entry) {
      var comment = entry.comment;
      return '<tr><td><span class="table-title">' + esc(commentSender(comment)) + '</span><span class="table-sub">' + esc(comment.email || '') + '</span></td><td style="white-space:pre-wrap">' + esc(commentText(comment) || '—') + '</td><td>' + esc(formattedDate(comment.createdAt || comment.date)) + '</td><td><button class="icon-btn danger" type="button" data-admin-action="delete-comment" data-index="' + attr(entry.index) + '">حذف</button></td></tr>';
    }).join('') : '<tr><td colspan="4"><div class="empty">لا توجد تعليقات حتى الآن.</div></td></tr>';
    return pageHead('التعليقات', 'تعليقات الزوار على المحتوى.') + '<section class="panel"><div class="notice warn">الحذف نهائي بعد التأكيد.</div><div class="table-wrap" style="margin-top:14px"><table><thead><tr><th>المرسل</th><th>التعليق</th><th>التاريخ</th><th>إجراء</th></tr></thead><tbody>' + body + '</tbody></table></div></section>';
  }
  function renderBackups() {
    return pageHead('النسخ الاحتياطي', 'احفظ نسخة من بيانات الموقع أو استعدها عند الحاجة.') + '<section class="split-panel"><div class="panel"><h2>تصدير نسخة JSON</h2><p class="muted">سيُنزَّل ملف يحتوي على الإعدادات والمحتوى والحسابات وسجل النشاط. احتفظ به في مكان خاص.</p><div class="form-actions"><button class="btn btn-primary" type="button" data-admin-action="export-backup">تنزيل نسخة احتياطية</button></div></div><div class="panel danger-zone"><h2>استيراد نسخة</h2><p class="muted">الاستيراد يستبدل البيانات الحالية بعد تأكيدك. تأكد أن الملف صادر من هذا الموقع وتجنّب الملفات غير الموثوقة.</p><input type="file" accept="application/json,.json" data-backup-file hidden><div class="form-actions"><button class="btn btn-outline" type="button" data-admin-action="import-trigger">اختيار ملف JSON</button></div></div></section><section class="panel"><h2>نصيحة</h2><p class="muted">احتفظ بنسخة احتياطية دورية في مكان آمن، خصوصًا قبل أي تحديث كبير.</p></section>';
  }
  function activityList(records, fallback) { if (!records || !records.length) return '<div class="empty">' + esc(fallback) + '</div>'; return '<ul class="activity-list">' + records.map(function (a) { return '<li><strong>' + esc(a.message || a.action || 'تم إجراء تغيير') + '</strong><time>' + esc(formattedDate(a.createdAt || a.date)) + '</time></li>'; }).join('') + '</ul>'; }
  function renderActivity() { return pageHead('سجل النشاط', 'آخر العمليات والأحداث الأمنية في الموقع.') + '<section class="panel">' + activityList(store().activity.slice(0, 100), 'لا يوجد نشاط مسجل حتى الآن.') + '</section>'; }
  function renderAdmin() {
    var user = activeUser();
    if (!user) return guestPanel('لوحة الإدارة', 'يلزم تسجيل الدخول للوصول إلى لوحة الإدارة.');
    if (!isAdmin(user)) return '<main class="fm-admin-app" data-fm-admin-root data-route="admin"><section class="auth-shell"><div class="panel"><h1>لا تملك صلاحية الإدارة</h1><p class="muted">حسابك لا يملك إذن المحرر أو المالك لفتح لوحة التحكم.</p><div class="form-actions"><button class="btn btn-primary" data-admin-action="navigate" data-route="profile">الملف الشخصي</button><button class="btn btn-outline" data-admin-action="logout">تسجيل الخروج</button></div></div></section></main>';
    var allowed = { dashboard: 'dashboard', content: 'content', consultations: 'consultations', comments: 'comments', settings: 'settings', users: 'users', backups: 'backups', activity: 'activity', sections: 'sections', notifications: 'notifications', stats: 'stats', maintenance: 'maintenance' };
    if (!allowed[state.tab] || !can(user, allowed[state.tab])) state.tab = 'dashboard';
    var views = { dashboard: renderDashboard, content: renderContent, consultations: renderConsultations, comments: renderComments, settings: renderSettings, users: renderUsers, backups: renderBackups, activity: renderActivity, sections: function () { return FMX.tab('sections'); }, notifications: function () { return FMX.tab('notifications'); }, stats: function () { return FMX.tab('stats'); }, maintenance: function () { return window.FMMaint ? window.FMMaint.render() : ''; } };
    return '<main class="fm-admin-app" data-fm-admin-root data-route="admin"><div class="admin-layout">' + adminNav(user) + '<section class="admin-main">' + views[state.tab]() + '</section></div></main>';
  }

  function adminNav(user) {
    var G = [['', [['dashboard', 'نظرة عامة', 'grid']]], ['المحتوى', [['content', 'المحتوى والمقالات', 'file'], ['sections', 'الأقسام والتصميم', 'layout']]], ['المجتمع', [['users', 'الأعضاء والصلاحيات', 'users'], ['comments', 'التعليقات', 'edit'], ['consultations', 'الاستشارات', 'mail'], ['notifications', 'الإشعارات', 'inbox']]], ['الموقع', [['settings', 'الإعدادات', 'settings'], ['maintenance', 'وضع الصيانة', 'wrench'], ['stats', 'الإحصائيات', 'layers']]], ['النظام', [['activity', 'النشاط والأمان', 'clock'], ['backups', 'النسخ الاحتياطي', 'bookmark']]]];
    var pend = store().items.filter(function (x) { return x.status === 'pending'; }).length;
    var nav = G.map(function (g) {
      var b = g[1].filter(function (i) { return can(user, i[0]); }).map(function (i) { return '<button type="button" class="' + (state.tab === i[0] ? 'active' : '') + '" data-admin-action="admin-tab" data-tab="' + i[0] + '">' + FM.icon(i[2]) + '<span>' + i[1] + '</span>' + (i[0] === 'content' && pend ? '<em class="fx-dot">' + pend + '</em>' : '') + '</button>'; }).join('');
      return b ? '<div class="fx-ng">' + (g[0] ? '<p class="fx-nl">' + g[0] + '</p>' : '') + b + '</div>' : '';
    }).join('');
    return '<aside class="admin-side"><div class="brand"><span class="brand-mark">ف</span><div><strong>' + esc(defaults().siteName || 'لوحتي') + '</strong><small>لوحة الإدارة</small></div></div><nav class="admin-nav" aria-label="تنقل لوحة الإدارة">' + nav + '</nav><div class="side-user"><strong>' + esc(user.name || user.username) + '</strong><br><span>' + (user.role === 'owner' ? 'المالك' : 'محرر') + '</span><small id="fm-cloud-status" style="display:block;margin:10px 0;color:#b9d8ff">جارٍ الاتصال بالمزامنة…</small><button type="button" id="fm-sync-now" class="btn btn-ghost btn-sm" style="color:#d5e9ea;padding:6px 0">مزامنة الآن</button><div class="fx-su"><button type="button" data-admin-action="navigate" data-route="home">عرض الموقع</button><button type="button" data-admin-action="navigate" data-route="profile">الملف الشخصي</button><button type="button" data-admin-action="logout">تسجيل الخروج</button></div></div></aside>';
  }
  function renderDashboard() {
    var s = store(), it = s.items, u = activeUser(), pend = it.filter(function (x) { return x.status === 'pending'; });
    var stats = [['منشور', it.filter(function (x) { return x.status === 'published'; }).length], ['بانتظار المراجعة', pend.length], ['الأعضاء', s.users.length], ['التعليقات', s.comments.length]].map(function (c) { return '<div class="stat-card"><span>' + c[0] + '</span><strong>' + c[1] + '</strong></div>'; }).join('');
    var pl = pend.length ? pend.slice(0, 6).map(function (x) { return '<div class="fx-pend"><div><strong>' + esc(x.title) + '</strong><span class="table-sub">' + esc(typeNames[x.type] || '') + ' · ' + esc(x.author || '') + '</span></div><div class="actions"><button class="btn btn-primary btn-sm" type="button" data-admin-action="approve-item" data-id="' + attr(x.id) + '">نشر</button><button class="btn btn-outline btn-sm" type="button" data-admin-action="edit-item" data-id="' + attr(x.id) + '">مراجعة</button><button class="btn btn-ghost btn-sm" type="button" data-admin-action="reject-item" data-id="' + attr(x.id) + '">إرجاع</button></div></div>'; }).join('') : '<div class="empty">لا توجد مواد بانتظار المراجعة.</div>';
    var qa = '<button class="btn btn-primary" type="button" data-admin-action="new-item">' + FM.icon('plus') + ' إضافة محتوى</button>' + (isOwner(u) ? '<button class="btn btn-outline" type="button" data-admin-action="admin-tab" data-tab="users">إضافة عضو</button><button class="btn btn-outline" type="button" data-admin-action="admin-tab" data-tab="notifications">نشر إشعار</button><button class="btn btn-outline" type="button" data-admin-action="admin-tab" data-tab="settings">إعدادات الموقع</button>' : '');
    return '<div class="fx-hello"><div><h1>مرحبًا ' + esc(String(u.name || u.username || '').split(' ')[0]) + '</h1><p>هذه نظرة سريعة على موقعك اليوم.</p></div><div class="fx-qa">' + qa + '</div></div>' + (u.mustChange ? '<div class="notice warn" style="margin-bottom:16px">كلمة مرور حسابك مؤقتة. <button class="btn btn-ghost btn-sm" type="button" data-admin-action="navigate" data-route="profile">غيّرها الآن</button></div>' : '') + (window.FMMaint && window.FMMaint.isOn() ? '<div class="notice warn" style="margin-bottom:16px">' + FM.icon('wrench') + '<span>وضع الصيانة <b>مفعّل</b> — الزوار يرون صفحة الصيانة فقط. <button class="btn btn-ghost btn-sm" type="button" data-admin-action="admin-tab" data-tab="maintenance">إدارة الصيانة</button></span></div>' : '') + '<div class="admin-card-grid">' + stats + '</div><div class="split-panel"><section class="panel"><h2>بانتظار مراجعتك</h2>' + pl + '</section><section class="panel"><div class="row"><h2>آخر النشاطات</h2><button class="btn btn-ghost btn-sm" type="button" data-admin-action="admin-tab" data-tab="activity">عرض الكل</button></div>' + activityList((s.activity || []).slice(0, 6), 'لا توجد نشاطات بعد.') + '</section></div>';
  }
  function renderUsers() {
    var owner = isOwner(activeUser());
    var users = store().users.slice().sort(function (a, b) { return String(a.createdAt || '').localeCompare(String(b.createdAt || '')); });
    var rows = users.map(function (u) {
      var role = u.role || 'member', acts = '—', id = attr(u.id);
      if (owner && role !== 'owner') acts = '<div class="actions"><button class="icon-btn" type="button" data-admin-action="toggle-user" data-id="' + id + '">' + (u.active === false ? 'تفعيل' : 'إيقاف') + '</button><button class="icon-btn" type="button" data-admin-action="' + (role === 'editor' ? 'set-user-member' : 'set-user-editor') + '" data-id="' + id + '">' + (role === 'editor' ? 'إلغاء التحرير' : 'ترقية لمحرر') + '</button><button class="icon-btn" type="button" data-admin-action="reset-pass" data-id="' + id + '">كلمة مرور</button><button class="icon-btn danger" type="button" data-admin-action="delete-user" data-id="' + id + '">حذف</button></div>';
      return '<tr><td><span class="table-title">' + esc(u.name || '—') + '</span><span class="table-sub">@' + esc(u.username || '—') + '</span></td><td dir="ltr">' + esc(u.email || '—') + '</td><td><span class="badge role-' + attr(role) + '">' + (role === 'owner' ? 'مالك' : role === 'editor' ? 'محرر' : 'عضو') + '</span>' + (u.fixed ? ' <span class="badge">حساب ثابت</span>' : '') + '</td><td>' + (u.active === false ? '<span class="badge trash">موقوف</span>' : '<span class="badge published">نشط</span>') + '</td><td>' + esc(formattedDate(u.createdAt)) + '</td><td>' + acts + '</td></tr>';
    }).join('');
    var form = owner ? '<form class="panel" data-admin-form="adduser" novalidate><h2>إضافة عضو</h2><p class="muted">ستصل للعضو رسالة دعوة لتفعيل حسابه وتعيين كلمة المرور بنفسه.</p><div class="form-grid"><div class="field"><label>الاسم *</label><input name="name" maxlength="80" required></div><div class="field"><label>اسم المستخدم *</label><input name="username" dir="ltr" required></div><div class="field"><label>البريد الإلكتروني *</label><input name="email" type="email" dir="ltr" required></div><div class="field"><label>رقم الجوال</label><input name="phone" inputmode="tel"></div><div class="field"><label>الصلاحية</label><select name="role"><option value="member">عضو</option><option value="editor">محرر محتوى</option></select></div></div><div class="form-actions"><button class="btn btn-primary" type="submit">إرسال دعوة التفعيل</button></div></form>' : '';
    return pageHead('الأعضاء والصلاحيات', 'أضف أعضاءً وتحكم في صلاحياتهم.') + form + '<section class="panel"><div class="table-wrap"><table><thead><tr><th>المستخدم</th><th>البريد</th><th>الدور</th><th>الحالة</th><th>تاريخ الإنشاء</th><th>إجراء</th></tr></thead><tbody>' + rows + '</tbody></table></div></section>';
  }
  function reviewItem(id, ok) {
    if (!can(activeUser(), 'content')) return toast('لا تملك إذن إدارة المحتوى.', true);
    var it = findItem(id); if (!it) return;
    it.status = ok ? 'published' : 'draft'; it.updatedAt = now(); log((ok ? 'نشر: ' : 'إرجاع إلى مسودة: ') + (it.title || '')); save(); toast(ok ? 'تم نشر المحتوى.' : 'أُعيد المحتوى إلى مسودة.'); refresh();
  }
  function render(route) {
    defaults();
    if (!FM) return '<main class="fm-admin-app" data-fm-admin-root><div class="panel notice error">تعذر تحميل عقد FM المطلوب لهذه الوحدة.</div></main>';
    if (route === 'profile') return window.FMAuthUI ? window.FMAuthUI.renderAccount() : guestPanel('الملف الشخصي', 'تعذر تحميل وحدة الحساب.');
    if (route === 'admin') return renderAdmin();
    return guestPanel('غير متاح', 'هذه الصفحة غير متاحة.');
  }

  function formData(form) { return new FormData(form); }
  function requiredText(fd, name) { return String(fd.get(name) || '').trim(); }
  function handleSettings(form) {
    var user = activeUser(); if (!can(user, 'settings')) return toast('لا تملك إذن تعديل الإعدادات.', true);
    var fd = formData(form), x = defaults(), orderKeys = ['news','article','project','gallery','service','about','contact'];
    var positions = orderKeys.map(function (key) { return Number(fd.get('order_' + key)); });
    if (positions.some(function (n) { return !Number.isInteger(n) || n < 1 || n > 7; }) || new Set(positions).size !== 7) return toast('استخدم الأرقام من 1 إلى 7 مرة واحدة لكل قسم.', true);
    if (!requiredText(fd, 'siteName')) return toast('أدخل اسم الموقع.', true);
    ['siteName', 'heroTitle', 'heroText', 'email', 'phone', 'x', 'snapchat', 'about', 'primary', 'termsText', 'privacyText'].forEach(function (key) { x[key] = requiredText(fd, key); });
    if (!/^#[0-9a-f]{6}$/i.test(x.primary)) x.primary = '#2458ef';
    x.sectionOrder = FMX.keepOrder(x.sectionOrder, orderKeys.slice().sort(function (a, b) { return Number(fd.get('order_' + a)) - Number(fd.get('order_' + b)); }));
    x.visible = x.visible || {}; ['news', 'article', 'project', 'gallery', 'service', 'about', 'contact'].forEach(function (key) { x.visible[key] = !!fd.get('visible_' + key); });
    x.updatedAt = now(); if (typeof FM.applySettings === 'function') FM.applySettings(); log('تم تحديث إعدادات الموقع'); save(); toast('تم حفظ إعدادات الموقع.'); refresh();
  }
  function itemForm(item) {
    item = item || {}; var isEdit = !!item.id;
    return '<form id="fm-admin-item-form" data-edit-id="' + attr(item.id || '') + '" novalidate><p class="modal-help">الحقول بعلامة * مطلوبة.</p><div class="form-grid"><div class="field wide"><label>العنوان *</label><input name="title" maxlength="180" required value="' + attr(item.title) + '"></div><div class="field"><label>النوع *</label><select name="type" data-item-type>' + typeOptions(item.type || 'news', false) + '</select></div><div class="field"><label>الحالة</label><select name="status">' + statusOptions(item.status || 'draft', false) + '</select></div><div class="field"><label>الفئة</label><input name="category" maxlength="80" value="' + attr(item.category) + '"></div><div class="field" data-progress-field' + ((item.type || 'news') === 'project' ? '' : ' hidden') + '><label>نسبة إنجاز المشروع (0–100)</label><input name="progress" type="number" min="0" max="100" value="' + attr(item.progress === undefined ? '' : item.progress) + '"></div><div class="field wide"><label>ملخص</label><textarea name="summary" maxlength="600">' + esc(item.summary) + '</textarea></div><div class="field wide"><label>المحتوى</label><textarea name="body" maxlength="12000">' + esc(item.body) + '</textarea></div><div class="field wide"><label>صورة الغلاف</label><input name="imageFile" type="file" accept="image/png,image/jpeg,image/webp,image/gif">' + (safeImage(item.image) ? '<span class="muted">ستبقى الصورة الحالية إن لم تختر ملفًا جديدًا.</span>' : '') + '</div></div><div class="form-actions"><button class="btn btn-primary" type="submit">' + (isEdit ? 'حفظ التعديلات' : 'إضافة المحتوى') + '</button><button class="btn btn-outline" type="button" data-admin-action="modal-close">إلغاء</button></div></form>';
  }
  function showItemModal(item) { if (!can(activeUser(), 'content')) return toast('لا تملك إذن إدارة المحتوى.', true); if (!FM || typeof FM.showModal !== 'function') return toast('نافذة التعديل غير متاحة في الصفحة الأم.', true); FM.showModal(item && item.id ? 'تعديل المحتوى' : 'إضافة محتوى', itemForm(item)); bindItemModal(); }
  function closeModal() { if (FM && typeof FM.closeModal === 'function') FM.closeModal(); }
  function consultationModal(record, index) {
    var text = String(record.text || record.body || '').trim(), reply = consultationReply(record), status = consultationStatus(record);
    return '<form id="fm-admin-consultation-form" data-consultation-id="' + attr(record.id || '') + '" data-consultation-index="' + attr(index) + '" novalidate><p class="modal-help">سيظهر ردك لصاحب الطلب في ملفه الشخصي.</p><dl class="kv"><dt>المرسل</dt><dd>' + esc(consultationSender(record)) + '</dd><dt>العنوان</dt><dd>' + esc(record.title || 'طلب استشارة') + '</dd><dt>الفئة</dt><dd>' + esc(consultationCategoryNames[consultationCategory(record.category)]) + '</dd><dt>التاريخ</dt><dd>' + esc(formattedDate(record.createdAt || record.date)) + '</dd></dl><div class="field" style="margin-top:14px"><label>نص الاستشارة</label><div class="notice" style="white-space:pre-wrap">' + esc(text || '—') + '</div></div><div class="form-grid" style="margin-top:14px"><div class="field"><label>الحالة</label><select name="status">' + consultationStatusOptions(status) + '</select></div><div class="field wide"><label>الرد *</label><textarea name="reply" maxlength="4000" required>' + esc(reply) + '</textarea></div></div><div class="form-actions"><button class="btn btn-primary" type="submit">حفظ الرد</button><button class="btn btn-outline" type="button" data-admin-action="modal-close">إلغاء</button></div></form>';
  }
  function showConsultationModal(id, index) {
    if (!isOwner(activeUser())) return toast('المالك فقط يستطيع عرض الاستشارات والرد عليها.', true);
    var record = findConsultation(id, index);
    if (!record) return toast('تعذر العثور على طلب الاستشارة.', true);
    if (!FM || typeof FM.showModal !== 'function') return toast('نافذة الرد غير متاحة في الصفحة الأم.', true);
    FM.showModal('عرض الاستشارة والرد', consultationModal(record, index)); bindConsultationModal();
  }
  function bindConsultationModal() {
    var form = document.getElementById('fm-admin-consultation-form');
    if (!form || form.dataset.bound) return;
    form.dataset.bound = '1';
    form.addEventListener('click', function (event) { var button = event.target.closest('[data-admin-action="modal-close"]'); if (button) { event.preventDefault(); closeModal(); } });
    form.addEventListener('submit', function (event) { event.preventDefault(); saveConsultationReply(form); });
  }
  function saveConsultationReply(form) {
    var user = activeUser();
    if (!isOwner(user)) return toast('المالك فقط يستطيع حفظ الردود.', true);
    var record = findConsultation(form.dataset.consultationId, form.dataset.consultationIndex), fd = formData(form), status = requiredText(fd, 'status'), reply = requiredText(fd, 'reply');
    if (!record) return toast('تعذر العثور على طلب الاستشارة.', true);
    if (!Object.prototype.hasOwnProperty.call(consultationStatusNames, status)) return toast('اختر حالة صالحة للطلب.', true);
    if (reply.length < 2 || reply.length > 4000) return toast('اكتب ردًا بين حرفين و4000 حرف.', true);
    record.reply = reply; record.status = status; record.repliedAt = now(); record.repliedById = user.id; record.repliedByName = user.name || user.username; record.updatedAt = now();
    log('تم الرد على استشارة: ' + (record.title || 'طلب استشارة')); save(); closeModal(); toast('تم حفظ الرد والحالة.'); refresh();
  }
  function bindItemModal() {
    var form = document.getElementById('fm-admin-item-form'); if (!form || form.dataset.bound) return; form.dataset.bound = '1';
    form.addEventListener('change', function (e) { if (e.target.matches('[data-item-type]')) { var f = form.querySelector('[data-progress-field]'); if (f) f.hidden = e.target.value !== 'project'; } });
    form.addEventListener('click', function (e) { var btn = e.target.closest('[data-admin-action="modal-close"]'); if (btn) { e.preventDefault(); closeModal(); } });
    form.addEventListener('submit', async function (e) { e.preventDefault(); await saveItemForm(form); });
  }
  async function saveItemForm(form) {
    var user = activeUser(); if (!can(user, 'content')) return toast('لا تملك إذن إدارة المحتوى.', true);
    var fd = formData(form), title = requiredText(fd, 'title'), type = requiredText(fd, 'type'), status = requiredText(fd, 'status');
    if (!title) return toast('العنوان مطلوب.', true); if (TYPES.indexOf(type) < 0 || STATUS.indexOf(status) < 0) return toast('قيم المحتوى غير صالحة.', true);
    var id = form.dataset.editId, item = id ? store().items.find(function (x) { return x.id === id; }) : null, image = item ? item.image : '';
    var file = fd.get('imageFile');
    if (file && file.size) {
      if (!/^image\/(png|jpeg|webp|gif)$/i.test(file.type)) return toast('اختر صورة PNG أو JPG أو WEBP أو GIF فقط.', true);
      try { image = await FM.readFile(file); } catch (e) { return toast('تعذر قراءة الصورة.', true); }
      if (!safeImage(image)) return toast('تعذر التحقق من الصورة.', true);
    }
    var progress = Number(fd.get('progress')); if (!Number.isFinite(progress)) progress = 0; progress = Math.min(100, Math.max(0, progress));
    if (!item) { item = { id: uid(), createdAt: now(), author: user.name || user.username, authorId: user.id, by: 'site' }; store().items.push(item); }
    item.type = type; item.title = title; item.summary = requiredText(fd, 'summary'); item.body = requiredText(fd, 'body'); item.category = requiredText(fd, 'category'); item.status = status; item.image = image || ''; item.progress = type === 'project' ? progress : 0; if (window.FMX) FMX.extra(item, fd); item.updatedAt = now(); store().settings.updatedAt = item.updatedAt;
    log((id ? 'تم تعديل المحتوى: ' : 'تمت إضافة محتوى: ') + title); save(); closeModal(); toast('تم حفظ المحتوى.'); refresh();
  }
  function findItem(id) { return store().items.find(function (item) { return item.id === id; }); }
  function updateItemStatus(id, status) { var item = findItem(id); if (!item || !can(activeUser(), 'content')) return; if (status === 'trash') { item.previousStatus = item.status === 'trash' ? 'draft' : item.status; } item.status = status; item.updatedAt = now(); store().settings.updatedAt = item.updatedAt; log((status === 'trash' ? 'تم نقل محتوى إلى سلة المحذوفات: ' : status === 'archived' ? 'تمت أرشفة محتوى: ' : 'تمت استعادة محتوى: ') + (item.title || '')); save(); toast('تم تحديث حالة المحتوى.'); refresh(); }
  function exportBackup() {
    if (!can(activeUser(), 'backups')) return toast('لا تملك إذن النسخ الاحتياطي.', true);
    var payload = { format: 'FM-local-backup', version: 1, exportedAt: now(), store: store() };
    var filename = 'fm-backup-' + new Date().toISOString().slice(0, 10) + '.json';
    if (FM && typeof FM.downloadFile === 'function') FM.downloadFile(filename, JSON.stringify(payload, null, 2), 'application/json'); else { var blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }); var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename; a.click(); URL.revokeObjectURL(a.href); }
    log('تم تصدير نسخة احتياطية'); save(); toast('تم تنزيل النسخة الاحتياطية.');
  }
  function validateBackup(data) {
    var x = data && data.store ? data.store : data;
    if (!x || typeof x !== 'object' || !x.settings || typeof x.settings !== 'object') return null;
    var arr = ['items', 'users', 'comments', 'contacts', 'consultations', 'favorites', 'activity'];
    if (arr.some(function (key) { return !Array.isArray(x[key]); })) return null;
    if (x.users.some(function (u) { return !u || typeof u !== 'object' || ('password' in u); })) return null;
    return x;
  }
  async function importBackup(file) {
    if (!can(activeUser(), 'backups')) return toast('لا تملك إذن النسخ الاحتياطي.', true);
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) return toast('حجم الملف أكبر من الحد المسموح (10 ميجابايت).', true);
    try {
      var text = await (file.text ? file.text() : new Promise(function (resolve, reject) { var reader = new FileReader(); reader.onload = function () { resolve(reader.result); }; reader.onerror = reject; reader.readAsText(file); }));
      var incoming = validateBackup(JSON.parse(text));
      if (!incoming) throw new Error('بنية النسخة غير صالحة أو تحتوي حقول كلمة مرور غير مسموحة.');
      if (!window.confirm('سيتم استبدال بيانات الموقع الحالية بالكامل. هل تريد المتابعة؟')) return;
      FM.store = incoming; defaults(); save(); if (typeof FM.applySettings === 'function') FM.applySettings(); log('تم استيراد نسخة احتياطية'); save(); toast('تم استيراد النسخة الاحتياطية.'); refresh();
    } catch (e) { toast(e.message || 'تعذر استيراد النسخة.', true); }
  }
  function applyItemFilters(root) {
    var rows = root.querySelectorAll('[data-item-row]'); var query = normalize(state.query); var shown = 0;
    rows.forEach(function (row) { var match = (state.itemType === 'all' || row.dataset.type === state.itemType) && (state.itemStatus === 'all' || row.dataset.status === state.itemStatus) && (!query || normalize(row.dataset.search).indexOf(query) > -1); row.hidden = !match; if (match) shown++; });
    var tbody = root.querySelector('[data-content-rows]'); var empty = tbody && tbody.querySelector('[data-filter-empty]'); if (!shown && rows.length) { if (!empty) { empty = document.createElement('tr'); empty.dataset.filterEmpty = '1'; empty.innerHTML = '<td colspan="5"><div class="empty">لا توجد نتائج مطابقة للبحث.</div></td>'; tbody.appendChild(empty); } } else if (empty) empty.remove();
  }
  function deleteLocalComment(index) {
    if (!isOwner(activeUser())) return toast('المالك فقط يستطيع حذف التعليقات.', true);
    var numericIndex = Number(index);
    if (!Number.isInteger(numericIndex) || numericIndex < 0 || numericIndex >= store().comments.length) return toast('تعذر العثور على التعليق.', true);
    var comment = store().comments[numericIndex];
    if (!comment) return toast('تعذر العثور على التعليق.', true);
    if (!window.confirm('هل تريد حذف هذا التعليق نهائيًا؟')) return;
    store().comments.splice(numericIndex, 1); log('تم حذف تعليق من: ' + commentSender(comment)); save(); toast('تم حذف التعليق.'); refresh();
  }
  function handleClick(event, root) {
    var button = event.target.closest('[data-admin-action]'); if (!button || !root.contains(button)) return;
    event.preventDefault(); var action = button.dataset.adminAction, id = button.dataset.id;
    if (action === 'navigate') return navigate(button.dataset.route);
    if (action === 'logout') { if (FM && typeof FM.clearSession === 'function') FM.clearSession(); return; }
    if (action === 'admin-tab') { state.tab = button.dataset.tab || 'dashboard'; return refresh(); }
    if (action === 'new-item') return showItemModal(null);
    if (action === 'edit-item') return showItemModal(findItem(id));
    if (action === 'delete-item') { var deleted = findItem(id); if (deleted && window.confirm('نقل «' + (deleted.title || 'هذا المحتوى') + '» إلى سلة المحذوفات؟')) updateItemStatus(id, 'trash'); return; }
    if (action === 'restore-item') { var restored = findItem(id); return updateItemStatus(id, restored && restored.previousStatus && restored.previousStatus !== 'trash' ? restored.previousStatus : 'draft'); }
    if (action === 'approve-item' || action === 'reject-item') return reviewItem(id, action === 'approve-item');
    if (action === 'archive-item') return updateItemStatus(id, 'archived');
    if (action === 'view-consultation') return showConsultationModal(id, button.dataset.index);
    if (action === 'delete-comment') return deleteLocalComment(button.dataset.index);
    if (/^(toggle-user|set-user-editor|set-user-member|reset-pass|delete-user)$/.test(action)) return; // handled by the cloud layer (data.js) for the owner only
    if (action.indexOf('maint-') === 0 && window.FMMaint) return window.FMMaint.click(action, button);
    if (window.FMX && FMX.click(action, button, id)) return;
    if (action === 'export-backup') return exportBackup();
    if (action === 'import-trigger') { var input = root.querySelector('[data-backup-file]'); if (input) input.click(); }
  }
  function bind(route) {
    var root = document.querySelector('[data-fm-admin-root]'); if (!root || root.dataset.bound) return; root.dataset.bound = '1';
    root.addEventListener('click', function (event) { handleClick(event, root); });
    root.addEventListener('submit', function (event) { var form = event.target.closest('form[data-admin-form]'); if (!form) return; event.preventDefault(); var kind = form.dataset.adminForm; if (kind === 'settings') handleSettings(form); else if (kind === 'maintenance' && window.FMMaint) window.FMMaint.submit(form); else if (/^(consultation|adduser|notice)$/.test(kind)) return; /* cloud layer (data.js) owns these */ else if (window.FMX) FMX.submit(kind, form); });
    root.addEventListener('input', function (event) { if (event.target.matches('[data-item-filter="query"]')) { state.query = event.target.value; applyItemFilters(root); } });
    root.addEventListener('change', function (event) { if (event.target.matches('[data-item-filter]')) { if (event.target.dataset.itemFilter === 'type') state.itemType = event.target.value; if (event.target.dataset.itemFilter === 'status') state.itemStatus = event.target.value; applyItemFilters(root); } if (event.target.matches('[data-backup-file]')) importBackup(event.target.files && event.target.files[0]); });
    if (route === 'admin') applyItemFilters(root);
  }

  window.FMAdmin = { render: render, bind: bind, consultations: renderProfileConsultations };
})(window, document);
