-- ============================================================
-- Fahad Mubarak V2 — additive migration (no data is deleted/changed)
-- 1) auto-create profiles for ANY signup method (email / OAuth / phone)
-- 2) maintenance mode stored in site_settings('maintenance')
-- 3) server-side enforcement: visitors cannot READ public content while
--    maintenance is on (owner bypasses). UI gate is only the first layer.
-- ============================================================

-- ---------- 1) profile auto-creation ----------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  dn text;
  av text;
begin
  dn := coalesce(
    nullif(btrim(new.raw_user_meta_data->>'display_name'), ''),
    nullif(btrim(new.raw_user_meta_data->>'full_name'), ''),
    nullif(btrim(new.raw_user_meta_data->>'name'), ''),
    nullif(btrim(new.raw_user_meta_data->>'user_name'), ''),
    nullif(split_part(coalesce(new.email, ''), '@', 1), ''),
    'عضو'
  );
  av := coalesce(
    nullif(new.raw_user_meta_data->>'avatar_url', ''),
    nullif(new.raw_user_meta_data->>'picture', '')
  );
  if av is not null and av !~* '^https://' then
    av := null;
  end if;
  insert into public.profiles (id, display_name, avatar_url)
  values (new.id, left(dn, 100), av)
  on conflict (id) do nothing;
  return new;
end;
$$;

revoke all on function public.handle_new_user() from public, anon, authenticated;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- 2) maintenance setting ----------
insert into public.site_settings (key, value)
values ('maintenance', jsonb_build_object(
  'enabled', false,
  'title',   'الموقع قيد الصيانة',
  'message', 'نعمل حاليًا على تطوير الموقع لنقدّم لكم تجربة أفضل. سنعود قريبًا بإذن الله.',
  'eta',     ''
))
on conflict (key) do nothing;

-- visitors may read the maintenance record (it only holds the public message)
alter policy site_settings_public_read on public.site_settings
  using (key = any (array['public_profile','homepage','navigation','theme','maintenance']));

-- SECURITY INVOKER on purpose: it only reads the publicly readable row.
create or replace function public.is_maintenance_on()
returns boolean
language sql
stable
set search_path = public
as $$
  select coalesce(
    (select (value->>'enabled')::boolean from public.site_settings where key = 'maintenance'),
    false
  );
$$;

-- ---------- 3) enforce on public reads (owner bypasses) ----------
alter policy content_public_select on public.content_items
  using (
    status = 'published'
    and (
      not public.is_maintenance_on()
      or ((select auth.jwt()) -> 'app_metadata' ->> 'role') = 'owner'
    )
  );

alter policy comments_public_select on public.comments
  using (
    status = 'approved'
    and (
      not public.is_maintenance_on()
      or ((select auth.jwt()) -> 'app_metadata' ->> 'role') = 'owner'
    )
  );

alter policy community_posts_read on public.community_posts
  using (
    not public.is_maintenance_on()
    or ((select auth.jwt()) -> 'app_metadata' ->> 'role') = 'owner'
  );

alter policy community_replies_read on public.community_replies
  using (
    not public.is_maintenance_on()
    or ((select auth.jwt()) -> 'app_metadata' ->> 'role') = 'owner'
  );

alter policy notifications_public_select on public.notifications
  using (
    user_id is null
    and (
      not public.is_maintenance_on()
      or ((select auth.jwt()) -> 'app_metadata' ->> 'role') = 'owner'
    )
  );

-- ---------- 4) small hardening ----------
-- only the owner may write the maintenance row (site_settings_owner_all already
-- enforces owner-only writes; nothing to add). Prevent oversized settings values:
alter table public.site_settings
  drop constraint if exists site_settings_value_size;
alter table public.site_settings
  add constraint site_settings_value_size check (octet_length(value::text) <= 200000) not valid;
