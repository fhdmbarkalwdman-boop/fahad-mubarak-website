// Supabase "Send SMS Hook" — sends the auth OTP through a generic HTTP SMS gateway.
// Secrets (set with `supabase secrets set`, never in the frontend):
//   SEND_SMS_HOOK_SECRET  e.g. "v1,whsec_..."  (from Auth → Hooks → Send SMS)
//   SMS_API_URL           gateway endpoint (Tawk/Taqnyat/other — per its docs)
//   SMS_API_KEY           gateway bearer token
//   SMS_SENDER            sender name (optional)
// Fails closed: bad signature or missing config => no SMS, error returned.
import { Webhook } from "https://esm.sh/standardwebhooks@1.0.0";

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { "content-type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method !== "POST") return json({ error: { http_code: 405, message: "method" } }, 405);
  const secret = (Deno.env.get("SEND_SMS_HOOK_SECRET") ?? "").replace("v1,whsec_", "");
  const url = Deno.env.get("SMS_API_URL"), key = Deno.env.get("SMS_API_KEY");
  if (!secret || !url || !key) return json({ error: { http_code: 500, message: "SMS hook not configured" } }, 500);

  const body = await req.text();
  let payload: { user: { phone: string }; sms: { otp: string } };
  try {
    payload = new Webhook(secret).verify(body, Object.fromEntries(req.headers)) as typeof payload;
  } catch {
    return json({ error: { http_code: 401, message: "invalid signature" } }, 401);
  }
  const phone = payload.user.phone.startsWith("+") ? payload.user.phone : "+" + payload.user.phone;
  const text = `رمز التحقق الخاص بك في موقع فهد مبارك: ${payload.sms.otp}`;
  try {
    const r = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${key}` },
      body: JSON.stringify({ to: phone, recipients: [phone], body: text, message: text, sender: Deno.env.get("SMS_SENDER") ?? "" }),
    });
    if (!r.ok) return json({ error: { http_code: 502, message: "gateway rejected" } }, 502);
  } catch {
    return json({ error: { http_code: 502, message: "gateway unreachable" } }, 502);
  }
  return json({});
});
