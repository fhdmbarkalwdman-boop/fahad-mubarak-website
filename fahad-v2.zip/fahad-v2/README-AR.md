# موقع فهد مبارك — الإصدار 2.0

موقع ثابت (Static) جاهز لـ Netlify، متصل بمشروع Supabase `jujkckphabzsfjcodefy`. لا توجد أسرار في الواجهة (المفتاح العام فقط).

## خطوات التفعيل (مرة واحدة)
1. **قاعدة البيانات**: شغّل `supabase/migrations/20261108_v2_auth_maintenance.sql` في Supabase → SQL Editor. بدونه لن تظهر صفحة الصيانة للزوار (تبويب «وضع الصيانة» → «فحص الربط» يخبرك بالحالة).
2. **Google / GitHub**: Authentication → Providers → فعّلهما وضع Client ID/Secret. رابط العودة المطلوب في المزوّد: `https://jujkckphabzsfjcodefy.supabase.co/auth/v1/callback`.
3. **Redirect URLs**: Authentication → URL Configuration → اجعل Site URL رابط الموقع الجديد على Netlify وأضفه (مع `/`) إلى Redirect URLs.
4. **OTP البريد**: في قوالب البريد (Magic Link / Confirm signup) أضف `{{ .Token }}` ليصل الرمز.
5. **SMS**: فعّل Phone provider، ثم Auth → Hooks → Send SMS → HTTPS واختر الدالة `send-sms-hook`. انشرها: `supabase functions deploy send-sms-hook --no-verify-jwt` وضع الأسرار: `SEND_SMS_HOOK_SECRET` و`SMS_API_URL` و`SMS_API_KEY` و`SMS_SENDER` (صيغة طلب البوابة قابلة للتعديل في `index.ts` حسب توثيق Tawked/مزوّدك).
6. **حماية كلمات المرور**: فعّل Leaked password protection من إعدادات Auth.

## ملاحظات
- مشروع الطيور لم يُمس.
- الأدوار من `app_metadata.role` (owner/editor). وضع الصيانة للمالك فقط، والمالك يتصفح الموقع أثناءه.
- الدخول يبقى متاحًا لصفحات login/forgot/reset أثناء الصيانة.
