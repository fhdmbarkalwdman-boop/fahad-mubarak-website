/* ============================================================
   auth.js — Supabase Auth for Fahad Mubarak V2
   Methods: Google · GitHub · email+password · email OTP · phone SMS OTP
   Roles are read ONLY from app_metadata (server-controlled), never from user_metadata.
   ============================================================ */
(() => {
  'use strict';
  const FM = window.FM, CFG = window.FM_CONFIG;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const esc = FM.esc;
  const ic = FM.icon;

  /* ---------- state ---------- */
  let client = null, authUser = null, profile = null, ready = false;
  const startUrl = new URL(location.href);
  const hadCode = startUrl.searchParams.has('code');
  const cbError = (() => {
    const h = new URLSearchParams((location.hash || '').replace(/^#/, ''));
    const q = startUrl.searchParams;
    return h.get('error_description') || q.get('error_description') || '';
  })();
  const AFTER_KEY = 'fm_after_auth';
  const cooldowns = {};

  const roleOf = u => ['owner', 'editor'].includes(u?.app_metadata?.role) ? u.app_metadata.role : 'member';
  const siteUrl = () => location.origin + '/';
  const toast = (m, bad = false) => FM.toast(m, bad);

  function mapped() {
    if (!authUser) return null;
    const md = authUser.user_metadata || {}, role = roleOf(authUser);
    const email = authUser.email || '';
    const avatar = profile?.avatar_url || md.avatar_url || md.picture || '';
    return {
      id: authUser.id,
      name: profile?.display_name || md.display_name || md.full_name || md.name || email.split('@')[0] || 'عضو',
      username: profile?.username || md.username || md.user_name || email.split('@')[0] || '',
      email,
      phone: authUser.phone || md.phone || '',
      phoneVerified: !!authUser.phone_confirmed_at,
      emailVerified: !!authUser.email_confirmed_at,
      providers: authUser.app_metadata?.providers || [],
      avatar: /^https:\/\//i.test(avatar) ? avatar : (profile?.avatar_url || ''),
      bio: profile?.bio || '',
      role, active: true,
      createdAt: authUser.created_at,
      permissions: role === 'owner' ? ['admin', 'content', 'consultations', 'comments', 'settings', 'users', 'backups', 'activity', 'maintenance']
        : role === 'editor' ? ['content', 'manage_content'] : []
    };
  }

  /* ---------- messages (Arabic) ---------- */
  function explain(e) {
    const m = String(e?.message || e || ''), c = String(e?.code || '');
    const t = (re) => re.test(m) || re.test(c);
    if (t(/invalid login credentials|invalid_credentials/i)) return 'البريد الإلكتروني أو كلمة المرور غير صحيحة.';
    if (t(/email not confirmed|email_not_confirmed/i)) return 'لم يتم تأكيد بريدك بعد. افتح رسالة التأكيد أو سجّل الدخول برمز البريد.';
    if (t(/already registered|user_already_exists|email_exists/i)) return 'هذا البريد مسجّل مسبقًا. جرّب تسجيل الدخول.';
    if (t(/phone_exists/i)) return 'رقم الجوال هذا مرتبط بحساب آخر.';
    if (t(/token has expired|otp_expired|invalid.*(token|otp)|otp.*invalid/i)) return 'الرمز غير صحيح أو انتهت صلاحيته. اطلب رمزًا جديدًا.';
    if (t(/rate limit|over_.*_rate_limit|only request this after|too many/i)) return 'محاولات كثيرة. انتظر قليلًا ثم أعد المحاولة.';
    if (t(/signups not allowed|signup_disabled|otp_disabled/i)) return 'لا يوجد حساب بهذه البيانات، أو أن التسجيل غير متاح. جرّب «حساب جديد».';
    if (t(/provider is not enabled|unsupported provider|validation_failed.*provider/i)) return 'هذا المزوّد غير مفعّل في إعدادات Supabase بعد.';
    if (t(/sms|phone.*provider|unsupported phone|hook/i)) return 'خدمة الرسائل القصيرة غير مُفعّلة بعد على الخادم. تواصل مع مدير الموقع.';
    if (t(/weak_password|pwned|compromised|should contain|at least/i)) return 'كلمة المرور ضعيفة أو سبق تسريبها. اختر كلمة أقوى (8 أحرف على الأقل).';
    if (t(/same_password|different from the old/i)) return 'كلمة المرور الجديدة يجب أن تختلف عن الحالية.';
    if (t(/reauth|recently|requires.*login/i)) return 'لأسباب أمنية سجّل الدخول من جديد ثم أعد المحاولة.';
    if (t(/manual linking|identity.*link/i)) return 'ربط الحسابات غير مفعّل في إعدادات Supabase.';
    if (t(/network|failed to fetch|load failed/i)) return 'تعذّر الاتصال بالخادم. تحقق من الإنترنت.';
    return m || 'تعذّر إكمال العملية. حاول مرة أخرى.';
  }

  /* ---------- profile ---------- */
  async function loadProfile() {
    profile = null;
    if (!authUser || !client) return;
    const sel = 'display_name,username,avatar_url,bio';
    const { data, error } = await client.from('profiles').select(sel).eq('id', authUser.id).maybeSingle();
    if (error) return;
    profile = data;
    const md = authUser.user_metadata || {};
    if (!profile) {
      const row = { id: authUser.id, display_name: String(md.display_name || md.full_name || md.name || md.user_name || authUser.email?.split('@')[0] || 'عضو').trim().slice(0, 100) };
      const av = md.avatar_url || md.picture;
      if (/^https:\/\//i.test(av || '')) row.avatar_url = av;
      const r = await client.from('profiles').upsert(row, { onConflict: 'id' }).select(sel).maybeSingle();
      if (!r.error) profile = r.data;
    } else if (!profile.username && /^[A-Za-z0-9._-]{3,32}$/.test(md.username || '')) {
      const r = await client.from('profiles').update({ username: md.username }).eq('id', authUser.id).select(sel).maybeSingle();
      if (!r.error && r.data) profile = r.data;
    }
  }

  function setAuth(user) { authUser = user || null; profile = null; }

  function syncUI() {
    const route = (() => { try { return decodeURIComponent((location.hash || '#home').slice(1)); } catch { return ''; } })();
    const cur = mapped();
    if (ready && cur && /^(login|register|setup)$/.test(route)) { FM.navigate(afterAuthRoute(cur)); return; }
    if (ready && route === 'authcb') { resolveCallback(); return; }
    FM.refresh();
    document.dispatchEvent(new CustomEvent('fm:supabase-auth', { detail: { ready, user: mapped() } }));
  }

  const homeFor = u => (u && ['owner', 'editor'].includes(u.role)) ? 'admin' : 'profile';
  function afterAuthRoute(u) {
    let r = '';
    try { r = sessionStorage.getItem(AFTER_KEY) || ''; sessionStorage.removeItem(AFTER_KEY); } catch { /* ignore */ }
    if (r && !/^(login|register|forgot|reset|setup|authcb)$/.test(r)) return r;
    return homeFor(u);
  }
  function rememberReturn() {
    try {
      const r = decodeURIComponent((location.hash || '').slice(1));
      if (r && !/^(login|register|forgot|reset|setup|authcb)$/.test(r) && !/^(access_token|error)/.test(r)) sessionStorage.setItem(AFTER_KEY, r);
    } catch { /* ignore */ }
  }

  /* ---------- phone helpers ---------- */
  const DIALS = [['+966', 'SA'], ['+971', 'AE'], ['+965', 'KW'], ['+974', 'QA'], ['+973', 'BH'], ['+968', 'OM'], ['+962', 'JO'], ['+20', 'EG'], ['+964', 'IQ'], ['+967', 'YE'], ['+212', 'MA'], ['+216', 'TN'], ['+213', 'DZ'], ['+90', 'TR'], ['+44', 'GB'], ['+1', 'US']];
  function toE164(dial, national) {
    let v = String(national || '').replace(/[\s\-().]/g, '');
    v = v.replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
    if (v.startsWith('+')) return /^\+\d{8,15}$/.test(v) ? v : '';
    if (v.startsWith('00')) v = v.slice(2); else {
      const dd = dial.replace('+', '');
      if (v.startsWith(dd) && v.length > dd.length + 6) v = v.slice(dd.length);
      v = v.replace(/^0+/, '');
      v = dd + v;
    }
    v = '+' + v.replace(/^\+/, '');
    return /^\+\d{8,15}$/.test(v) ? v : '';
  }
  const dialSelect = (name = 'dial') => `<select name="${name}" aria-label="رمز الدولة">${DIALS.map(([d, c]) => `<option value="${d}"${d === CFG.DEFAULT_DIAL ? ' selected' : ''}>${d} · ${c}</option>`).join('')}</select>`;
  const phoneField = (label = 'رقم الجوال') => `<div class="field"><label>${label}</label><div class="phone-field">${dialSelect()}<input name="phone" type="tel" inputmode="tel" autocomplete="tel-national" placeholder="5XXXXXXXX" required></div></div>`;

  /* ---------- api ---------- */
  const API = {
    async signInPassword(email, password) {
      const { data, error } = await client.auth.signInWithPassword({ email, password });
      if (error) throw error; return data;
    },
    async signUp({ email, password, name, username, phone }) {
      const meta = { display_name: name };
      if (username) meta.username = username;
      if (phone) meta.phone = phone;
      const { data, error } = await client.auth.signUp({ email, password, options: { data: meta, emailRedirectTo: siteUrl() } });
      if (error) throw error;
      if (data.user && Array.isArray(data.user.identities) && data.user.identities.length === 0) { const e = new Error('User already registered'); e.code = 'user_already_exists'; throw e; }
      return data;
    },
    async oauth(provider) {
      rememberReturn();
      const options = { redirectTo: siteUrl() };
      if (provider === 'google') options.queryParams = { prompt: 'select_account' };
      const { error } = await client.auth.signInWithOAuth({ provider, options });
      if (error) throw error;
    },
    async emailOtp(email, create, name) {
      const options = { shouldCreateUser: !!create, emailRedirectTo: siteUrl() };
      if (create && name) options.data = { display_name: name };
      const { error } = await client.auth.signInWithOtp({ email, options }); if (error) throw error;
    },
    async verifyEmail(email, token, type = 'email') {
      const { data, error } = await client.auth.verifyOtp({ email, token, type }); if (error) throw error; return data;
    },
    async phoneOtp(phone, create, name) {
      const options = { shouldCreateUser: !!create, channel: 'sms' };
      if (create && name) options.data = { display_name: name };
      const { error } = await client.auth.signInWithOtp({ phone, options }); if (error) throw error;
    },
    async verifyPhone(phone, token, type = 'sms') {
      const { data, error } = await client.auth.verifyOtp({ phone, token, type }); if (error) throw error; return data;
    },
    async forgot(email) {
      const { error } = await client.auth.resetPasswordForEmail(email, { redirectTo: siteUrl() }); if (error) throw error;
    },
    async setPassword(password) {
      const { error } = await client.auth.updateUser({ password }); if (error) throw error;
    },
    async startPhoneChange(phone) {
      const { error } = await client.auth.updateUser({ phone }); if (error) throw error;
    },
    async link(provider) {
      const { error } = await client.auth.linkIdentity({ provider, options: { redirectTo: siteUrl() } }); if (error) throw error;
    },
    async identities() {
      const { data, error } = await client.auth.getUserIdentities(); if (error) throw error; return data?.identities || [];
    },
    async signOut() {
      const { error } = await client.auth.signOut(); if (error) toast(explain(error), true);
      setAuth(null); syncUI();
    }
  };

  /* ---------- UI helpers ---------- */
  const GOOGLE = '<svg viewBox="0 0 48 48" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.5 5.8c4.4-4.1 7.1-10.1 7.1-17.5z"/><path fill="#FBBC05" d="M10.5 28.7A14.5 14.5 0 0 1 9.5 24c0-1.6.3-3.2.8-4.7l-7.9-6.1A24 24 0 0 0 0 24c0 3.9.9 7.5 2.6 10.8l7.9-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.5-5.8c-2.1 1.4-4.8 2.3-8.4 2.3-6.3 0-11.6-4.1-13.5-9.8l-7.9 6.1C6.5 42.6 14.6 48 24 48z"/></svg>';
  const GITHUB = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 .5a11.5 11.5 0 0 0-3.64 22.41c.58.1.79-.25.79-.56v-2c-3.2.7-3.87-1.37-3.87-1.37-.52-1.33-1.28-1.69-1.28-1.69-1.05-.71.08-.7.08-.7 1.15.08 1.76 1.19 1.76 1.19 1.03 1.76 2.7 1.25 3.36.96.1-.75.4-1.25.73-1.54-2.55-.29-5.24-1.28-5.24-5.69 0-1.26.45-2.28 1.19-3.09-.12-.29-.52-1.46.11-3.05 0 0 .97-.31 3.17 1.18a11 11 0 0 1 5.78 0c2.2-1.49 3.17-1.18 3.17-1.18.63 1.59.23 2.76.11 3.05.74.81 1.19 1.83 1.19 3.09 0 4.42-2.69 5.39-5.25 5.68.41.36.78 1.06.78 2.14v3.17c0 .31.21.67.8.56A11.5 11.5 0 0 0 12 .5Z"/></svg>';
  const logoHtml = () => `<a href="#home" class="brand" aria-label="فهد مبارك — الرئيسية"><span class="brand-mark">F<span>.</span></span><span class="brand-copy"><strong>${esc(FM.store.settings.siteName)}</strong><small>FAHAD MUBARAK</small></span></a>`;

  function setMsg(root, kind, text) {
    const box = $('.auth-msg', root); if (!box) return;
    if (!text) { box.hidden = true; box.textContent = ''; return; }
    box.hidden = false; box.className = 'auth-msg ' + (kind === 'ok' ? 'ok' : 'err'); box.textContent = text;
  }
  function busy(btn, on, label) {
    if (!btn) return;
    if (on) { btn.dataset.label = btn.innerHTML; btn.disabled = true; btn.innerHTML = '<span class="spin"></span> ' + esc(label || 'لحظة…'); }
    else { btn.disabled = false; if (btn.dataset.label) btn.innerHTML = btn.dataset.label; }
  }
  function startCooldown(btn, key) {
    if (!btn) return;
    clearInterval(cooldowns[key]);
    let n = CFG.OTP_RESEND_SECONDS; btn.disabled = true;
    const tick = () => { if (!btn.isConnected) { clearInterval(cooldowns[key]); return; } btn.textContent = n > 0 ? `إعادة الإرسال بعد ${n} ث` : 'إعادة إرسال الرمز'; if (n-- <= 0) { clearInterval(cooldowns[key]); btn.disabled = false; } };
    tick(); cooldowns[key] = setInterval(tick, 1000);
  }
  const otpHtml = () => `<div class="otp-boxes" data-otp dir="ltr">${[0, 1, 2, 3, 4, 5].map(i => `<input class="otp-box" inputmode="numeric" pattern="[0-9]*" maxlength="1" ${i === 0 ? 'autocomplete="one-time-code"' : ''} aria-label="الرقم ${i + 1}">`).join('')}</div>`;
  const readOtp = root => $$('.otp-box', root).map(i => i.value.replace(/\D/g, '')).join('');
  function passMeter(v) {
    let s = 0; if (v.length >= 8) s++; if (/[a-z]/.test(v) && /[A-Z]/.test(v)) s++; if (/\d/.test(v)) s++; if (/[^A-Za-z0-9]/.test(v) || v.length >= 14) s++;
    return v ? s : 0;
  }
  const passField = (name, label, auto = 'current-password', meter = false) => `<div class="field"><label>${label}</label><div class="pass-wrap"><input name="${name}" type="password" minlength="8" autocomplete="${auto}" required dir="ltr" style="text-align:right"><button type="button" class="pass-toggle" data-auth-action="toggle-pass" aria-label="إظهار كلمة المرور">${ic('eye')}</button></div>${meter ? '<div class="pass-meter" data-s="0"><i></i><i></i><i></i><i></i></div>' : ''}</div>`;

  /* ---------- auth pages ---------- */
  function otpPanel(kind, mode) {
    const isEmail = kind === 'email';
    const register = mode === 'register';
    return `<div class="auth-form" data-method-panel="${kind}" hidden>
      <form class="auth-form" data-auth-form="${kind}-request" novalidate>
        ${register ? '<div class="field"><label>الاسم (اختياري)</label><input name="name" maxlength="80" autocomplete="name"></div>' : ''}
        ${isEmail ? '<div class="field"><label>البريد الإلكتروني</label><input name="email" type="email" dir="ltr" autocomplete="email" required placeholder="name@example.com" style="text-align:right"></div>' : phoneField()}
        ${register ? '<label class="check"><input type="checkbox" name="consent"> <span>أوافق على <a class="link-btn" href="#terms" target="_blank" rel="noopener">الشروط</a> و<a class="link-btn" href="#privacy" target="_blank" rel="noopener">الخصوصية</a></span></label>' : ''}
        <button class="btn btn-primary btn-block" type="submit">${ic(isEmail ? 'mail' : 'phone')} إرسال الرمز</button>
        <p class="form-note" style="margin:0">${isEmail ? 'سنرسل رمزًا من 6 أرقام إلى بريدك.' : 'سنرسل رمزًا من 6 أرقام برسالة SMS إلى جوالك.'}</p>
      </form>
      <form class="auth-form" data-auth-form="${kind}-verify" data-create="${register ? '1' : ''}" novalidate hidden>
        <div class="otp-sent">${ic(isEmail ? 'mail' : 'phone')}<span>أرسلنا الرمز إلى <b data-otp-target></b></span></div>
        ${otpHtml()}
        <button class="btn btn-primary btn-block" type="submit">${ic('shield')} تأكيد الرمز</button>
        <div class="row-between"><button type="button" class="link-btn" data-auth-action="resend" data-kind="${kind}"></button><button type="button" class="link-btn" data-auth-action="back-step" data-kind="${kind}">${isEmail ? 'تغيير البريد' : 'تغيير الرقم'}</button></div>
      </form>
    </div>`;
  }

  function authPage(mode) {
    const register = mode === 'register';
    const art = `<aside class="auth-art"><div class="hero-aurora" aria-hidden="true"><i></i><i></i><i></i></div>${logoHtml()}
      <div><h2>${register ? 'انضم إلى <span>مساحة الأفكار</span> والمشاريع.' : 'أهلًا بعودتك إلى <span>مساحتك الرقمية</span>.'}</h2></div>
      <ul class="auth-points"><li><span>${ic('shield')}</span>دخول آمن عبر Google أو GitHub أو رمز تحقق</li><li><span>${ic('bookmark')}</span>احفظ مفضلتك وتابعها من أي جهاز</li><li><span>${ic('users')}</span>شارك في المجتمع واكتب مقالاتك</li></ul></aside>`;
    const social = `<div class="auth-social"><button type="button" class="btn-social google" data-auth-action="oauth" data-provider="google">${GOOGLE}<span>Google</span></button><button type="button" class="btn-social github" data-auth-action="oauth" data-provider="github">${GITHUB}<span>GitHub</span></button></div><div class="auth-divider"><span>أو بالطريقة التقليدية</span></div>`;
    const methods = `<div class="method-tabs" role="tablist"><button type="button" class="method-tab active" data-auth-action="method" data-method="password">${ic('key')} كلمة المرور</button><button type="button" class="method-tab" data-auth-action="method" data-method="email">${ic('mail')} رمز البريد</button><button type="button" class="method-tab" data-auth-action="method" data-method="phone">${ic('phone')} رمز الجوال</button></div>`;
    const passwordLogin = `<form class="auth-form" data-method-panel="password" data-auth-form="login-password" novalidate>
        <div class="field"><label>البريد الإلكتروني</label><input name="email" type="email" dir="ltr" autocomplete="username" required placeholder="name@example.com" style="text-align:right"></div>
        ${passField('password', 'كلمة المرور')}
        <div class="row-between"><span></span><a class="link-btn" href="#forgot">نسيت كلمة المرور؟</a></div>
        <button class="btn btn-primary btn-block" type="submit">${ic('lock')} تسجيل الدخول</button></form>`;
    const passwordRegister = `<form class="auth-form" data-method-panel="password" data-auth-form="register-password" novalidate>
        <div class="form-grid"><div class="field"><label>الاسم</label><input name="name" maxlength="80" autocomplete="name" required></div><div class="field"><label>اسم المستخدم (اختياري)</label><input name="username" dir="ltr" maxlength="32" autocomplete="username" pattern="[A-Za-z0-9._-]{3,32}" placeholder="fahad.m" style="text-align:right"></div></div>
        <div class="field"><label>البريد الإلكتروني</label><input name="email" type="email" dir="ltr" autocomplete="email" required placeholder="name@example.com" style="text-align:right"></div>
        ${passField('password', 'كلمة المرور (8 أحرف فأكثر)', 'new-password', true)}
        ${passField('confirm', 'تأكيد كلمة المرور', 'new-password')}
        <label class="check"><input type="checkbox" name="consent"> <span>أوافق على <a class="link-btn" href="#terms" target="_blank" rel="noopener">الشروط والأحكام</a> و<a class="link-btn" href="#privacy" target="_blank" rel="noopener">سياسة الخصوصية</a></span></label>
        <button class="btn btn-primary btn-block" type="submit">${ic('user')} إنشاء الحساب</button></form>
        <form class="auth-form" data-auth-form="signup-verify" novalidate hidden>
          <div class="otp-sent">${ic('mail')}<span>أرسلنا رسالة تأكيد إلى <b data-otp-target></b>. اضغط الرابط فيها، أو أدخل الرمز إن وُجد:</span></div>
          ${otpHtml()}
          <button class="btn btn-primary btn-block" type="submit">${ic('shield')} تأكيد الحساب</button>
          <div class="row-between"><span></span><button type="button" class="link-btn" data-auth-action="back-step" data-kind="signup">رجوع</button></div></form>`;
    const card = `<div class="auth-card"><a class="auth-back" href="#home">${ic('arrow-up-right')} العودة إلى الموقع</a>
      <div class="auth-tabs"><a href="#login" class="${register ? '' : 'active'}">تسجيل الدخول</a><a href="#register" class="${register ? 'active' : ''}">حساب جديد</a></div>
      <h1>${register ? 'أنشئ حسابك' : 'سجّل دخولك'}</h1><p class="muted">${register ? 'اختر الطريقة الأنسب لك — كلها تنتهي بحساب واحد آمن.' : 'اختر طريقة الدخول المناسبة لك.'}</p>
      ${social}${methods}<div class="auth-msg" role="alert" hidden></div>
      <div class="auth-form" style="margin-top:14px">${register ? passwordRegister : passwordLogin}${otpPanel('email', mode)}${otpPanel('phone', mode)}</div>
      <p class="auth-foot">${register ? 'لديك حساب؟ <a href="#login">سجّل دخولك</a>' : 'ليس لديك حساب؟ <a href="#register">أنشئ حسابًا</a>'}</p></div>`;
    return `<main class="auth-page" data-auth-root data-auth-route="${mode}" data-mode="${mode}">${art}<section class="auth-main">${card}</section></main>`;
  }

  function simplePage(route, inner) {
    return `<main class="auth-page" data-auth-root data-auth-route="${route}"><aside class="auth-art"><div class="hero-aurora" aria-hidden="true"><i></i><i></i><i></i></div>${logoHtml()}<div><h2>حسابك <span>في أمان</span>.</h2></div><ul class="auth-points"><li><span>${ic('lock')}</span>كلمات المرور لا تُخزَّن في المتصفح</li><li><span>${ic('shield')}</span>جلسات محمية ومشفّرة عبر Supabase</li></ul></aside><section class="auth-main"><div class="auth-card"><a class="auth-back" href="#login">${ic('arrow-up-right')} العودة لتسجيل الدخول</a>${inner}</div></section></main>`;
  }
  const forgotPage = () => simplePage('forgot', `<h1>استعادة كلمة المرور</h1><p class="muted">أدخل بريدك وسنرسل لك رابطًا آمنًا لتعيين كلمة مرور جديدة.</p><div class="auth-msg" role="alert" hidden></div><form class="auth-form" data-auth-form="forgot" novalidate style="margin-top:14px"><div class="field"><label>البريد الإلكتروني</label><input name="email" type="email" dir="ltr" autocomplete="email" required style="text-align:right"></div><button class="btn btn-primary btn-block" type="submit">${ic('mail')} إرسال رابط الاستعادة</button></form><p class="auth-foot">تذكّرت كلمة المرور؟ <a href="#login">سجّل دخولك</a> · أو ادخل <a href="#login">برمز البريد</a></p>`);
  const resetPage = () => authUser
    ? simplePage('reset', `<h1>كلمة مرور جديدة</h1><p class="muted">اختر كلمة مرور قوية لحسابك${authUser.email ? ' <b dir="ltr">' + esc(authUser.email) + '</b>' : ''}.</p><div class="auth-msg" role="alert" hidden></div><form class="auth-form" data-auth-form="reset" novalidate style="margin-top:14px">${passField('password', 'كلمة المرور الجديدة', 'new-password', true)}${passField('confirm', 'تأكيد كلمة المرور', 'new-password')}<button class="btn btn-primary btn-block" type="submit">${ic('check')} حفظ كلمة المرور</button></form>`)
    : simplePage('reset', `<h1>الرابط غير صالح</h1><p class="muted">انتهت صلاحية رابط الاستعادة أو تم استخدامه. اطلب رابطًا جديدًا.</p><a class="btn btn-primary" href="#forgot">طلب رابط جديد</a>`);
  const callbackPage = () => simplePage('authcb', `<h1>جارٍ التحقق…</h1><p class="muted">نُكمل تسجيل دخولك، لحظات.</p><div class="row" style="justify-content:center;padding:20px"><span class="spin" style="width:34px;height:34px;color:var(--blue)"></span></div>`);

  /* ---------- account page ---------- */
  const providerMeta = { google: ['Google', GOOGLE], github: ['GitHub', GITHUB], email: ['البريد وكلمة المرور', ic('mail')], phone: ['رقم الجوال', ic('phone')] };
  function accountPage() {
    const u = mapped();
    if (!u) return `<main class="fm-admin-app" data-fm-admin-root data-route="profile"><section class="auth-shell"><div class="panel"><h1>الملف الشخصي</h1><p class="muted">سجّل الدخول أولًا لعرض حسابك.</p><div class="form-actions"><a class="btn btn-primary" href="#login">تسجيل الدخول</a></div></div></section></main>`;
    const roleName = u.role === 'owner' ? 'المالك' : u.role === 'editor' ? 'محرر' : 'عضو';
    const avatar = u.avatar ? `<img src="${esc(u.avatar)}" alt="">` : esc((u.name || '؟').trim().charAt(0));
    const hasPassword = u.providers.includes('email');
    const idn = u.providers.map(p => { const m = providerMeta[p] || [p, ic('user')]; return `<div class="idn">${m[1]}<div><b>${esc(m[0])}</b></div><span class="badge published">${ic('check')} مرتبط</span></div>`; }).join('');
    const canLink = ['google', 'github'].filter(p => !u.providers.includes(p));
    const consult = window.FMAdmin?.consultations ? window.FMAdmin.consultations(u) : '';
    return `<main class="fm-admin-app acct" data-fm-admin-root data-route="profile"><section class="container">
      <div class="acct-hero"><div class="acct-av">${avatar}</div>
        <div><h1>${esc(u.name)}</h1><p>${esc(u.email || u.phone || '')}</p><div class="badges"><span class="badge role-${esc(u.role)}">${roleName}</span>${u.emailVerified ? `<span class="badge ok">${ic('check')} بريد موثّق</span>` : u.email ? '<span class="badge">بريد غير موثّق</span>' : ''}${u.phoneVerified ? `<span class="badge ok">${ic('check')} جوال موثّق</span>` : ''}</div></div>
        <div class="actions">${['owner', 'editor'].includes(u.role) ? `<a class="btn btn-light btn-sm" href="#admin">${ic('settings')} لوحة الإدارة</a>` : ''}<button class="btn btn-light btn-sm" type="button" data-fx-logout>${ic('logout')} تسجيل الخروج</button></div></div>
      <div class="acct-grid"><div class="acct-col">
        <section class="panel"><h2>بيانات الحساب</h2><p class="muted">الاسم الذي يظهر في المجتمع والتعليقات.</p>
          <form data-acct-form="name" novalidate><div class="form-grid"><div class="field wide"><label>الاسم</label><input name="name" maxlength="80" required value="${esc(u.name)}"></div><div class="field"><label>اسم المستخدم</label><input value="${esc(u.username)}" readonly dir="ltr" style="text-align:right"></div><div class="field"><label>البريد الإلكتروني</label><input value="${esc(u.email)}" readonly dir="ltr" style="text-align:right" placeholder="—"></div></div><div class="form-actions"><button class="btn btn-primary" type="submit">حفظ الاسم</button></div></form></section>
        <section class="panel"><h2>الصورة والنبذة</h2><p class="muted">صورة PNG أو JPG أو WEBP حتى 3 ميغابايت.</p>
          <form id="fx-prof-form"><div class="avatar-row"><span class="fx-av">${avatar}</span><input type="file" name="av" accept="image/png,image/jpeg,image/webp" aria-label="صورة الحساب"></div><div class="field"><label>نبذة قصيرة</label><textarea name="bio" maxlength="240">${esc(u.bio)}</textarea></div><div class="form-actions"><button class="btn btn-primary" type="submit">حفظ</button></div></form></section>
        ${consult}
      </div><div class="acct-col">
        <section class="panel"><h2>رقم الجوال</h2><p class="muted">${u.phoneVerified ? 'رقمك موثّق ويمكن استخدامه لتسجيل الدخول.' : 'وثّق رقمك برمز SMS لاستخدامه في تسجيل الدخول.'}</p>
          <div class="auth-msg" role="alert" hidden></div>
          <div class="phone-verify">${u.phone ? `<div class="idn">${ic('phone')}<div><b dir="ltr">${esc(u.phone)}</b></div><span class="badge ${u.phoneVerified ? 'published' : 'pending'}">${u.phoneVerified ? 'موثّق' : 'غير موثّق'}</span></div>` : ''}
          <form data-acct-form="phone-request" class="auth-form" novalidate>${phoneField(u.phone ? 'تغيير الرقم / توثيق' : 'رقم الجوال')}<button class="btn btn-outline" type="submit">${ic('phone')} إرسال رمز التحقق</button></form>
          <form data-acct-form="phone-verify" class="auth-form" novalidate hidden><div class="otp-sent">${ic('phone')}<span>أدخل الرمز المرسل إلى <b data-otp-target></b></span></div>${otpHtml()}<button class="btn btn-primary" type="submit">${ic('shield')} تأكيد الرقم</button></form></div></section>
        <section class="panel"><h2>الأمان</h2><p class="muted">${hasPassword ? 'غيّر كلمة المرور.' : 'حسابك مرتبط بمزوّد خارجي. يمكنك إضافة كلمة مرور للدخول بها أيضًا.'}</p>
          <div class="auth-msg" role="alert" hidden></div>
          <form data-acct-form="password" class="auth-form" novalidate>${passField('password', 'كلمة المرور الجديدة', 'new-password', true)}${passField('confirm', 'تأكيد كلمة المرور', 'new-password')}<button class="btn btn-outline" type="submit">${ic('lock')} تحديث كلمة المرور</button></form></section>
        <section class="panel"><h2>طرق الدخول المرتبطة</h2><p class="muted">الحسابات التي يمكنك الدخول بها.</p><div class="idn-list">${idn || '<div class="empty">لا توجد بيانات.</div>'}</div>
          ${canLink.length ? `<div class="form-actions">${canLink.map(p => `<button class="btn btn-outline btn-sm" type="button" data-acct-action="link" data-provider="${p}">${ic('link')} ربط ${providerMeta[p][0]}</button>`).join('')}</div>` : ''}</section>
      </div></div></section></main>`;
  }

  /* ---------- public UI API ---------- */
  const UI = {
    render(route) {
      if (route === 'forgot') return forgotPage();
      if (route === 'reset') return resetPage();
      if (route === 'authcb') return callbackPage();
      return authPage(route === 'register' ? 'register' : 'login');
    },
    bind(route) {
      const u = mapped();
      if (u && (route === 'login' || route === 'register' || route === 'setup')) { setTimeout(() => FM.navigate(afterAuthRoute(u)), 0); return; }
      if (route === 'authcb' && ready) setTimeout(resolveCallback, 0);
      const first = $('[data-auth-root] input:not([type=checkbox]):not([type=hidden])');
      if (first && matchMedia('(min-width:900px)').matches) setTimeout(() => { try { first.focus({ preventScroll: true }); } catch { /* ignore */ } }, 80);
      selectMethod(sessionStorage.getItem('fm_method') || 'password');
    },
    /* true => core.render() must NOT replace the view (protects typed codes/forms) */
    keep(route) {
      const root = $('[data-auth-root]');
      if (root && root.dataset.authRoute === (route === 'setup' ? 'login' : route)) return true;
      const acct = $('[data-route="profile"].acct');
      return !!(acct && route === 'profile' && acct.contains(document.activeElement) && /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName));
    },
    renderAccount: accountPage
  };
  window.FMAuthUI = UI;

  function selectMethod(m) {
    const root = $('[data-auth-root]'); if (!root) return;
    $$('.method-tab', root).forEach(t => t.classList.toggle('active', t.dataset.method === m));
    $$('[data-method-panel]', root).forEach(p => { p.hidden = p.dataset.methodPanel !== m; });
    setMsg(root, '', '');
  }

  /* ---------- callback resolution ---------- */
  function resolveCallback() {
    if (location.hash && /^#(access_token|refresh_token|type|error)/.test(location.hash) && !authUser) {
      /* supabase-js clears the hash after parsing; wait for it */
    }
    const u = mapped();
    if (u) FM.navigate(afterAuthRoute(u));
    else { if (cbError) toast(explain({ message: cbError }), true); FM.navigate('login'); }
  }

  /* ---------- events ---------- */
  async function onClick(e) {
    const a = e.target.closest('[data-auth-action],[data-acct-action]'); if (!a) return;
    const root = a.closest('[data-auth-root],[data-route="profile"]') || document;
    const scope = a.closest('.auth-card') || a.closest('.panel') || root;
    if (a.dataset.authAction === 'toggle-pass') {
      const inp = $('input', a.parentElement); const show = inp.type === 'password'; inp.type = show ? 'text' : 'password';
      a.innerHTML = ic(show ? 'eye-off' : 'eye'); return;
    }
    if (a.dataset.authAction === 'method') { sessionStorage.setItem('fm_method', a.dataset.method); selectMethod(a.dataset.method); return; }
    if (a.dataset.authAction === 'oauth') {
      const provider = a.dataset.provider; busy(a, true, '');
      try { await API.oauth(provider); } catch (err) { busy(a, false); setMsg(scope, 'err', explain(err)); }
      return;
    }
    if (a.dataset.authAction === 'back-step') {
      const kind = a.dataset.kind;
      if (kind === 'signup') { $('[data-auth-form="signup-verify"]', root).hidden = true; $('[data-auth-form="register-password"]', root).hidden = false; }
      else { const p = $(`[data-method-panel="${kind}"]`, root); $(`[data-auth-form="${kind}-verify"]`, p).hidden = true; $(`[data-auth-form="${kind}-request"]`, p).hidden = false; }
      setMsg(scope, '', ''); return;
    }
    if (a.dataset.authAction === 'resend') {
      const kind = a.dataset.kind, p = $(`[data-method-panel="${kind}"]`, root), v = $(`[data-auth-form="${kind}-verify"]`, p);
      const target = v.dataset.target, create = !!v.dataset.create;
      a.disabled = true;
      try { if (kind === 'email') await API.emailOtp(target, create); else await API.phoneOtp(target, create); toast('أُعيد إرسال الرمز.'); startCooldown(a, kind); }
      catch (err) { a.disabled = false; setMsg(scope, 'err', explain(err)); }
      return;
    }
    if (a.dataset.acctAction === 'link') {
      try { await API.link(a.dataset.provider); } catch (err) { toast(explain(err), true); }
    }
  }

  async function onSubmit(e) {
    const f = e.target.closest('[data-auth-form],[data-acct-form]'); if (!f) return;
    e.preventDefault(); e.stopImmediatePropagation();
    if (!client || !ready) return toast('جارٍ تهيئة الاتصال الآمن. أعد المحاولة بعد لحظة.', true);
    const root = f.closest('[data-auth-root]') || f.closest('[data-route="profile"]') || document;
    const scope = f.closest('.panel') || f.closest('.auth-card') || root;
    const kind = f.dataset.authForm || f.dataset.acctForm;
    const fd = new FormData(f), val = n => String(fd.get(n) || '').trim();
    const btn = $('button[type=submit]', f);
    const emailOk = v => /^\S+@\S+\.\S+$/.test(v);
    const fail = m => setMsg(scope, 'err', m);
    setMsg(scope, '', '');
    try {
      if (kind === 'login-password') {
        if (!emailOk(val('email'))) return fail('أدخل بريدًا إلكترونيًا صحيحًا.');
        if (!val('password')) return fail('أدخل كلمة المرور.');
        busy(btn, true, 'جارٍ الدخول…');
        const d = await API.signInPassword(val('email'), String(fd.get('password')));
        await onSignedIn(d.user, 'تم تسجيل الدخول بنجاح.');
      } else if (kind === 'register-password') {
        const pass = String(fd.get('password') || '');
        if (!val('name')) return fail('أدخل الاسم.');
        if (val('username') && !/^[A-Za-z0-9._-]{3,32}$/.test(val('username'))) return fail('اسم المستخدم: 3–32 حرفًا إنجليزيًا أو أرقامًا أو . _ -');
        if (!emailOk(val('email'))) return fail('أدخل بريدًا إلكترونيًا صحيحًا.');
        if (pass.length < 8) return fail('كلمة المرور يجب ألا تقل عن 8 أحرف.');
        if (pass !== String(fd.get('confirm') || '')) return fail('تأكيد كلمة المرور غير مطابق.');
        if (!fd.get('consent')) return fail('يلزم الموافقة على الشروط وسياسة الخصوصية.');
        busy(btn, true, 'جارٍ إنشاء الحساب…');
        const d = await API.signUp({ email: val('email'), password: pass, name: val('name'), username: val('username') });
        if (d.session) await onSignedIn(d.user, 'تم إنشاء حسابك بنجاح.');
        else { f.hidden = true; const v = $('[data-auth-form="signup-verify"]', root); v.hidden = false; v.dataset.target = val('email'); $('[data-otp-target]', v).textContent = val('email'); $('.otp-box', v)?.focus(); }
      } else if (kind === 'signup-verify') {
        const code = readOtp(f); if (code.length < 6) return fail('أدخل الرمز المكوّن من 6 أرقام.');
        busy(btn, true, 'جارٍ التأكيد…');
        const d = await API.verifyEmail(f.dataset.target, code, 'signup'); await onSignedIn(d.user, 'تم تأكيد حسابك.');
      } else if (kind === 'email-request' || kind === 'phone-request') {
        const isEmail = kind === 'email-request', create = root.dataset.mode === 'register';
        if (create && !fd.get('consent')) return fail('يلزم الموافقة على الشروط وسياسة الخصوصية.');
        let target;
        if (isEmail) { target = val('email'); if (!emailOk(target)) return fail('أدخل بريدًا إلكترونيًا صحيحًا.'); }
        else { target = toE164(val('dial'), val('phone')); if (!target) return fail('رقم الجوال غير صحيح. أدخله بدون رمز الدولة أو بصيغة +9665XXXXXXXX.'); }
        busy(btn, true, 'جارٍ الإرسال…');
        if (isEmail) await API.emailOtp(target, create, val('name')); else await API.phoneOtp(target, create, val('name'));
        const k = isEmail ? 'email' : 'phone', p = $(`[data-method-panel="${k}"]`, root), v = $(`[data-auth-form="${k}-verify"]`, p);
        f.hidden = true; v.hidden = false; v.dataset.target = target; $('[data-otp-target]', v).textContent = target;
        $$('.otp-box', v).forEach(i => { i.value = ''; }); $('.otp-box', v).focus();
        startCooldown($('[data-auth-action=resend]', v), k);
        setMsg(scope, 'ok', isEmail ? 'تم إرسال الرمز إلى بريدك.' : 'تم إرسال الرمز إلى جوالك.');
      } else if (kind === 'email-verify' || kind === 'phone-verify') {
        const code = readOtp(f); if (code.length < 6) return fail('أدخل الرمز المكوّن من 6 أرقام.');
        busy(btn, true, 'جارٍ التأكيد…');
        const d = kind === 'email-verify' ? await API.verifyEmail(f.dataset.target, code, 'email') : await API.verifyPhone(f.dataset.target, code, 'sms');
        await onSignedIn(d.user, 'تم التحقق وتسجيل الدخول.');
      } else if (kind === 'forgot') {
        if (!emailOk(val('email'))) return fail('أدخل بريدًا إلكترونيًا صحيحًا.');
        busy(btn, true, 'جارٍ الإرسال…'); await API.forgot(val('email'));
        setMsg(scope, 'ok', 'إن كان البريد مسجّلًا فستصلك رسالة تحتوي رابط الاستعادة خلال دقائق.');
      } else if (kind === 'reset' || kind === 'password') {
        const pass = String(fd.get('password') || '');
        if (pass.length < 8) return fail('كلمة المرور يجب ألا تقل عن 8 أحرف.');
        if (pass !== String(fd.get('confirm') || '')) return fail('تأكيد كلمة المرور غير مطابق.');
        busy(btn, true, 'جارٍ الحفظ…'); await API.setPassword(pass);
        toast('تم تحديث كلمة المرور بنجاح.'); f.reset();
        if (kind === 'reset') { await loadProfile(); FM.navigate(homeFor(mapped())); } else setMsg(scope, 'ok', 'تم تحديث كلمة المرور.');
      } else if (kind === 'name') {
        if (!val('name')) return toast('أدخل الاسم.', true);
        busy(btn, true, 'جارٍ الحفظ…');
        const { error } = await client.from('profiles').upsert({ id: authUser.id, display_name: val('name').slice(0, 100), updated_at: new Date().toISOString() }, { onConflict: 'id' });
        if (error) throw error;
        await loadProfile(); toast('تم حفظ الاسم.'); syncUI();
      }
    } catch (err) {
      if (kind === 'name') toast(explain(err), true); else fail(explain(err));
    } finally { busy(btn, false); }
  }

  /* account: phone change flow (shares kind names, so handled in a dedicated listener) */
  async function onAcctPhone(e) {
    const f = e.target.closest('[data-acct-form^="phone-"]'); if (!f) return;
    e.preventDefault(); e.stopImmediatePropagation();
    const root = f.closest('[data-route="profile"]'), scope = f.closest('.panel') || root, btn = $('button[type=submit]', f), fd = new FormData(f);
    setMsg(scope, '', '');
    try {
      if (f.dataset.acctForm === 'phone-request') {
        const phone = toE164(String(fd.get('dial')), String(fd.get('phone') || ''));
        if (!phone) return setMsg(scope, 'err', 'رقم الجوال غير صحيح.');
        busy(btn, true, 'جارٍ الإرسال…'); await API.startPhoneChange(phone);
        const v = $('[data-acct-form="phone-verify"]', root); v.dataset.target = phone; $('[data-otp-target]', v).textContent = phone; v.hidden = false; $('.otp-box', v).focus();
        setMsg(scope, 'ok', 'تم إرسال رمز التحقق إلى جوالك.');
      } else {
        const code = readOtp(f); if (code.length < 6) return setMsg(scope, 'err', 'أدخل الرمز المكوّن من 6 أرقام.');
        busy(btn, true, 'جارٍ التأكيد…'); await API.verifyPhone(f.dataset.target, code, 'phone_change');
        const r = await client.auth.getUser(); if (!r.error) authUser = r.data.user;
        toast('تم توثيق رقم جوالك.'); syncUI();
      }
    } catch (err) { setMsg(scope, 'err', explain(err)); } finally { busy(btn, false); }
  }

  async function onSignedIn(user, message) {
    setAuth(user); await loadProfile(); ready = true;
    toast(message);
    const u = mapped(); FM.navigate(afterAuthRoute(u)); syncUI();
  }

  /* OTP boxes: auto-advance, backspace, paste */
  function onOtpInput(e) {
    const b = e.target.closest('.otp-box'); if (!b) return;
    b.value = b.value.replace(/\D/g, '').slice(-1);
    if (b.value && b.nextElementSibling) b.nextElementSibling.focus();
    const wrap = b.parentElement; if (readOtp(wrap).length === 6) { const form = b.closest('form'); form?.requestSubmit?.(); }
  }
  function onOtpKey(e) {
    const b = e.target.closest('.otp-box'); if (!b) return;
    if (e.key === 'Backspace' && !b.value && b.previousElementSibling) { b.previousElementSibling.focus(); b.previousElementSibling.value = ''; }
    if (e.key === 'ArrowLeft' && b.nextElementSibling) b.nextElementSibling.focus();
    if (e.key === 'ArrowRight' && b.previousElementSibling) b.previousElementSibling.focus();
  }
  function onOtpPaste(e) {
    const b = e.target.closest('.otp-box'); if (!b) return;
    const txt = (e.clipboardData?.getData('text') || '').replace(/\D/g, '').slice(0, 6); if (!txt) return;
    e.preventDefault(); const boxes = $$('.otp-box', b.parentElement);
    txt.split('').forEach((c, i) => { if (boxes[i]) boxes[i].value = c; });
    (boxes[Math.min(txt.length, 5)]).focus();
    if (txt.length === 6) b.closest('form')?.requestSubmit?.();
  }
  function onPassInput(e) {
    const i = e.target.closest('input[name=password]'); if (!i) return;
    const m = i.closest('.field')?.querySelector('.pass-meter'); if (m) m.dataset.s = String(passMeter(i.value));
  }

  /* ---------- boot ---------- */
  function boot() {
    if (!window.supabase?.createClient) { toast('تعذر تحميل مكتبة تسجيل الدخول.', true); document.documentElement.dataset.gate = 'open'; return; }
    client = window.supabase.createClient(CFG.SUPABASE_URL, CFG.SUPABASE_KEY, { auth: { flowType: 'pkce', persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } });
    FM.user = () => mapped();
    FM.setSession = () => { };
    FM.clearSession = () => { API.signOut().then(() => { FM.navigate('home'); toast('تم تسجيل الخروج.'); }); };

    document.addEventListener('click', onClick);
    document.addEventListener('submit', e => { if (e.target.closest('[data-acct-form^="phone-"]')) return onAcctPhone(e); return onSubmit(e); }, true);
    document.addEventListener('input', e => { onOtpInput(e); onPassInput(e); });
    document.addEventListener('keydown', onOtpKey);
    document.addEventListener('paste', onOtpPaste);

    client.auth.onAuthStateChange((event, session) => {
      setAuth(session?.user || null);
      // never await supabase calls inside this callback (deadlock risk): defer
      setTimeout(async () => {
        await loadProfile(); ready = true;
        const u = mapped();
        if (event === 'PASSWORD_RECOVERY') FM.navigate('reset');
        else if (event === 'SIGNED_IN' && (hadCode || /authcb/.test(location.hash))) { FM.navigate(afterAuthRoute(u)); }
        syncUI();
        if (event === 'SIGNED_IN' && hadCode) toast('تم تسجيل الدخول بنجاح.');
      }, 0);
    });
    client.auth.getSession().then(async ({ data, error }) => {
      if (error) throw error;
      if (!authUser && data.session?.user) setAuth(data.session.user);
      await loadProfile(); ready = true;
      if (cbError && !data.session) { toast(explain({ message: cbError }), true); FM.navigate('login'); }
      if (/^#(access_token|type=|error)/.test(location.hash) && !data.session) FM.navigate('login');
      syncUI();
    }).catch(err => { ready = true; toast(explain(err), true); syncUI(); });

    window.FahadSupabase = {
      client, get user() { return mapped(); }, get ready() { return ready; }, signOut: () => API.signOut(),
      async refreshProfile() { await loadProfile(); FM.refresh(); return mapped(); },
      async updateProfile(values = {}) {
        if (!authUser) throw new Error('سجّل الدخول أولاً.');
        const patch = { display_name: String(values.display_name || mapped().name || 'عضو').trim().slice(0, 100), bio: String(values.bio || '').trim().slice(0, 240), updated_at: new Date().toISOString() };
        if (values.avatar_url) patch.avatar_url = values.avatar_url;
        const { data, error } = await client.from('profiles').upsert({ id: authUser.id, ...patch }, { onConflict: 'id' }).select('display_name,username,avatar_url,bio').single();
        if (error) throw error; profile = data; syncUI(); return mapped();
      }
    };
    window.FahadAuth = API;
  }
  boot();
})();
